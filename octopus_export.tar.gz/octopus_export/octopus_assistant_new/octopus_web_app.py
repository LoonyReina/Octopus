#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Octopus Pet Web App — 章鱼宠物轻量Web前端
功能：提供Web聊天界面，支持图片上传，桥接OpenClaw/OrbitAI API
运行：python3 octopus_web_app.py
访问：http://你的香橙派IP:5000
"""
from flask import Flask, render_template_string, request, jsonify, session
import os
import base64
import requests
import json
import time
from pathlib import Path

# ---------------------------------------------------------------------------
# 配置项（和你的OpenClaw配置完全一致！）
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = "octopus_pet_secret_key_2026"
API_KEY = os.environ.get("ORBITAI_API_KEY", "")
BASE_URL = os.environ.get("ORBITAI_BASE_URL", "https://api.space-ai.cn/v1")
MODEL_NAME = "gpt-5.4"
BRIDGE_SOCKET = "/tmp/octopus_behavior.sock"

# ---------------------------------------------------------------------------
# 全局变量
# ---------------------------------------------------------------------------
conversation_history = []

# ---------------------------------------------------------------------------
# Web路由
# ---------------------------------------------------------------------------
@app.route('/')
def index():
    return render_template_string('''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🐙 章鱼宠物助手</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #0c1929 0%, #1a3a5c 100%);
            color: #e0e6ed;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #2a4a6c;
            background: rgba(0,0,0,0.2);
        }
        .chat-container {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            max-width: 900px;
            margin: 0 auto;
            width: 100%;
        }
        .message {
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
        }
        .message.user { justify-content: flex-end; }
        .message.assistant { justify-content: flex-start; }
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
        }
        .user .avatar { background: #1976d2; }
        .assistant .avatar { background: #0288d1; }
        .bubble {
            max-width: 70%;
            padding: 15px 20px;
            border-radius: 18px;
            line-height: 1.6;
        }
        .user .bubble { background: #1565c0; border-bottom-right-radius: 4px; }
        .assistant .bubble { background: #01579b; border-bottom-left-radius: 4px; }
        .bubble img { max-width: 100%; border-radius: 10px; margin-top: 10px; }
        .input-area {
            padding: 20px;
            border-top: 1px solid #2a4a6c;
            background: rgba(0,0,0,0.2);
        }
        .input-wrapper {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        .text-input {
            flex: 1;
            background: #0a1628;
            border: 1px solid #2a4a6c;
            border-radius: 25px;
            padding: 15px 20px;
            color: #e0e6ed;
            font-size: 16px;
            outline: none;
            min-height: 50px;
        }
        .upload-btn, .send-btn {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: none;
            background: #0288d1;
            color: white;
            font-size: 20px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🐙 章鱼宠物助手</h1>
    </div>
    
    <div class="chat-container" id="chatContainer"></div>
    
    <div class="input-area">
        <div class="input-wrapper">
            <input type="file" id="imageInput" accept="image/*" style="display:none">
            <button class="upload-btn" onclick="document.getElementById('imageInput').click()">📷</button>
            <textarea class="text-input" id="textInput" placeholder="输入消息..."></textarea>
            <button class="send-btn" onclick="sendMessage()">➤</button>
        </div>
    </div>

    <script>
        let selectedImage = null;

        document.getElementById('imageInput').addEventListener('change', function(e) {
            selectedImage = e.target.files[0];
        });

        function sendMessage() {
            const text = document.getElementById('textInput').value.trim();
            if (!text && !selectedImage) return;

            const formData = new FormData();
            formData.append('text', text);
            if (selectedImage) formData.append('image', selectedImage);

            fetch('/chat', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    const container = document.getElementById('chatContainer');
                    container.innerHTML += `<div class="message user"><div class="bubble">${text}</div><div class="avatar">👤</div></div>`;
                    container.innerHTML += `<div class="message assistant"><div class="avatar">🐙</div><div class="bubble">${data.result}</div></div>`;
                    document.getElementById('textInput').value = '';
                    selectedImage = null;
                });
        }
    </script>
</body>
</html>
''')

@app.route('/chat', methods=['POST'])
def chat():
    text = request.form.get('text', '')
    image = request.files.get('image', None)

    image_base64 = None
    if image:
        image_data = image.read()
        image_base64 = base64.b64encode(image_data).decode('utf-8')

    messages = []
    content = []
    if text:
        content.append({"type": "text", "text": text})
    if image_base64:
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{image_base64}"}
        })

    messages.append({"role": "user", "content": content})

    try:
        resp = requests.post(
            f"{BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": MODEL_NAME,
                "messages": messages,
                "max_tokens": 2048
            },
            timeout=60
        )
        result = resp.json()
        reply = result["choices"][0]["message"]["content"]
        return jsonify({"status": "ok", "result": reply})
    except Exception as e:
        return jsonify({"status": "error", "result": str(e)})

if __name__ == '__main__':
    print("🐙 章鱼宠物Web前端启动中...")
    print(f"📱 访问地址：http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)