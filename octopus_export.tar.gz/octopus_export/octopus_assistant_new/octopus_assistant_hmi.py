#!/usr/bin/env python3
"""章鱼助手 HMI 版 — 主程序入口.

基于 TJC HMI 上位机设计的章鱼助手，通过串口指令控制：
- 切换表情（Picture 控件 pic 属性）
- 更新文字（Text 控件 txt 属性）
- 接收触摸（Button / Hotspot 组件事件）
- 自动眨眼动画
- 唤醒/休眠状态机
- 对话历史

核心变化（对比 v2 矢量版）：
- 不再需要实时绘制每一帧，大幅降低 CPU 占用
- 不再受帧率限制，表情切换即时响应
- 界面效果由 HMI 上位机设计，更精细可控

用法:
    python3 octopus_assistant_hmi.py
    python3 octopus_assistant_hmi.py --debug
    python3 octopus_assistant_hmi.py --offline
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import threading
import time
from collections import deque
from typing import Deque, Dict, List, Optional

sys.path.insert(0, "/home/openEuler/octopus_assistant")

from config_vertical import VerticalConfig
from octopus_pkg.hmi_controller import (
    BlinkManager,
    HMIController,
    OctopusEmotion,
    HMIEevent,
    EMOTION_PIC_MAP,
)
from octopus_pkg.openclaw_vertical import (
    OpenClawClient,
    OpenClawCallbacks,
    MessageType,
)
from octopus_pkg.tts_client import TTSClient
from octopus_pkg.voice_pipeline import VoicePipeline
from octopus_pkg.claw_controller import ClawController
from octopus_pkg.vision_engine import VisionEngine
from octopus_pkg.utils import setup_logging, FPSCounter

logger = logging.getLogger("octopus.hmi")


# ============================================================================
# 对话历史
# ============================================================================

# ============================================================================
# 直接 LLM 客户端（绕过 OpenClaw 格式问题）
# ============================================================================

class DirectLLMClient:
    """直接调用 orbitai API，绕过 OpenClaw 的 schema/tool 兼容问题."""

    def __init__(
        self,
        api_key: str = "",
        base_url: str = "https://aiapi.orbitai.global/v1",
        model: str = "gpt-5.4",
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._history: List[Dict[str, str]] = []

    def chat(self, user_message: str) -> str:
        """发送消息并获取回复."""
        import urllib.request

        self._history.append({"role": "user", "content": user_message})

        payload = {
            "model": self.model,
            "messages": self._history[-10:],  # 保留最近 10 轮上下文
            "max_tokens": 1024,
            "temperature": 0.7,
        }

        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                reply = data["choices"][0]["message"]["content"]
                self._history.append({"role": "assistant", "content": reply})
                return reply
        except Exception as e:
            logger.error("LLM 请求失败: %s", e)
            return f"抱歉，我现在有点累，稍后再聊吧~ ({type(e).__name__})"

    def reset(self) -> None:
        """重置对话历史."""
        self._history.clear()


# ============================================================================
# 对话历史
# ============================================================================

class DialogHistory:
    """对话历史记录器.

    内存中维护最近 N 条对话记录，支持按 logs 按钮查看摘要.
    """

    def __init__(self, max_size: int = 50) -> None:
        self._entries: Deque[dict] = deque(maxlen=max_size)
        self._max_size = max_size

    def add(self, role: str, text: str) -> None:
        """添加一条对话记录.

        Args:
            role: "user" 或 "assistant"
            text: 对话内容
        """
        self._entries.append({
            "role": role,
            "text": text[:100],
            "time": time.strftime("%H:%M:%S"),
        })
        logger.debug("对话历史 +1: [%s] %s", role, text[:40])

    def get_summary(self, count: int = 5) -> str:
        """获取最近 N 条对话的摘要.

        由于 t_message 是单行文本控件，用 | 分隔多条记录.
        """
        recent = list(self._entries)[-count:]
        if not recent:
            return "暂无对话记录"

        parts = []
        for entry in recent:
            prefix = "用" if entry["role"] == "user" else "助"
            text = entry["text"][:20]
            parts.append(f"{prefix}:{text}")

        return " | ".join(parts)

    def clear(self) -> None:
        """清空历史."""
        self._entries.clear()
        logger.info("对话历史已清空")

    def __len__(self) -> int:
        return len(self._entries)


# ============================================================================
# Behavior Engine 通知器
# ============================================================================

class BehaviorEngineNotifier:
    """通过 Unix Domain Socket 向 behavior_engine 发送事件.

    当串口屏表情变化、会话开始/结束、用户操作时，
    通知 behavior_engine 调度其他硬件（舵机、LED、TTS 等）。
    """

    # behavior_mapping.yaml 中已注册的情绪名
    KNOWN_EMOTIONS = {"happy", "sad", "curious", "confident", "angry"}

    def __init__(self, socket_path: str = "/tmp/octopus_behavior.sock") -> None:
        self.socket_path = socket_path
        self._available = False

    def check_available(self) -> bool:
        """检查 behavior_engine 是否正在运行."""
        self._available = os.path.exists(self.socket_path)
        return self._available

    def notify(self, event_type: str, payload: dict, priority: int = 5) -> bool:
        """发送事件到 behavior_engine.

        Args:
            event_type: "emotion" | "action" | "detection" | "system"
            payload: 事件载荷，如 {"emotion": "happy"}
            priority: 优先级（0=最高，5=默认）

        Returns:
            True 表示发送成功，False 表示失败或引擎未运行
        """
        if not self._available and not self.check_available():
            return False

        try:
            import socket as socket_lib

            sock = socket_lib.socket(socket_lib.AF_UNIX, socket_lib.SOCK_STREAM)
            sock.settimeout(1.0)
            sock.connect(self.socket_path)
            data = {
                "event_type": event_type,
                "payload": payload,
                "priority": priority,
                "source": "hmi_app",
            }
            sock.sendall(json.dumps(data, ensure_ascii=False).encode("utf-8") + b"\n")
            sock.close()
            logger.debug("通知 BE: %s %s", event_type, payload)
            return True
        except Exception as e:
            logger.debug("BE 通知失败: %s", e)
            return False

    def notify_emotion(self, emotion: str) -> bool:
        """通知表情变化（仅发送 behavior_engine 认识的情绪）."""
        if emotion not in self.KNOWN_EMOTIONS:
            return False
        return self.notify("emotion", {"emotion": emotion}, priority=3)

    def notify_action(self, action: str, extra: Optional[dict] = None) -> bool:
        """通知动作事件."""
        payload = {"action": action}
        if extra:
            payload.update(extra)
        return self.notify("action", payload, priority=2)


# ============================================================================
# OpenClaw 回调实现
# ============================================================================

class OctopusCallbacks(OpenClawCallbacks):
    """章鱼助手的 OpenClaw 回调实现（HMI 版）."""

    def __init__(
        self,
        app: "OctopusAssistantHMI",
        notifier: Optional[BehaviorEngineNotifier] = None,
    ) -> None:
        self.app = app
        self.notifier = notifier

    def on_emotion_change(self, emotion: str) -> None:
        """表情变化 -> 发送 pic 切换指令 + 通知 behavior_engine."""
        try:
            octopus_emotion = OctopusEmotion(emotion)
            self.app.set_emotion(octopus_emotion)
            logger.info("表情切换: %s", emotion)
            if self.notifier:
                self.notifier.notify_emotion(emotion)
        except ValueError:
            logger.warning("未知表情: %s", emotion)

    def on_session_start(self, session_id: str) -> None:
        """会话开始 -> 确保已唤醒，显示挥手表情 + 通知 BE."""
        self.app.wake_up()
        self.app.set_emotion(OctopusEmotion.WAVING)
        self.app.hmi.set_status_text(f"会话 {session_id[:6]}...")
        self.app.hmi.set_conn_status("已连接", color=2016)
        logger.info("会话开始: %s", session_id)
        if self.notifier:
            self.notifier.notify_action("chat")

    def on_session_end(self) -> None:
        """会话结束 -> 回到 AWAKE（caring 表情）."""
        self.app.set_emotion(OctopusEmotion.CARING)
        self.app.hmi.set_status_text("章鱼助手")
        self.app.hmi.set_message_text("")
        logger.info("会话结束，回到 AWAKE 状态")

    def on_user_message(self, text: str) -> None:
        """用户消息 -> 记录历史 + 关心表情 + 通知 BE."""
        self.app.dialog_history.add("user", text)
        self.app.set_emotion(OctopusEmotion.CARING)
        self.app.hmi.set_message_text(f"你说: {text[:30]}")
        self.app._mark_activity()
        if self.notifier:
            self.notifier.notify_action("chat", {"context": "user_message"})

    def on_assistant_reply(self, text: str) -> None:
        """助手回复 -> 记录历史 + 开心表情 + 朗读 + 3秒后恢复关心 + 通知 BE."""
        self.app.dialog_history.add("assistant", text)
        self.app.set_emotion(OctopusEmotion.HAPPY)
        self.app.hmi.set_message_text(f" {text[:40]}")
        self.app.tts.speak(text)
        self.app._mark_activity()
        if self.notifier:
            self.notifier.notify_action("chat", {"context": "assistant_reply"})

        # 3秒后恢复关心表情
        def _reset():
            time.sleep(3.0)
            self.app.set_emotion(OctopusEmotion.CARING)
            self.app.hmi.set_message_text("")

        threading.Thread(target=_reset, daemon=True).start()

    def on_connection_change(self, connected: bool) -> None:
        """连接状态变化."""
        if connected:
            self.app.hmi.set_conn_status("已连接", color=2016)
            self.app.set_emotion(OctopusEmotion.HAPPY)
            logger.info("OpenClaw 已连接")
        else:
            self.app.hmi.set_conn_status("断开", color=63488)
            # 不再强制回到 SLEEP，让用户保持当前界面状态
            logger.warning("OpenClaw 断开连接")

    def on_error(self, error: str) -> None:
        """错误 -> 委屈表情."""
        self.app.set_emotion(OctopusEmotion.SAD)
        self.app.hmi.set_message_text(f" {error[:30]}")
        logger.error("OpenClaw 错误: %s", error)


# ============================================================================
# 触控处理
# ============================================================================

class HMITouchHandler:
    """HMI 版触控处理器.

    接收串口屏返回的 0x65 组件触控事件，映射为业务动作。
    组件 ID 映射（与 HMI 上位机实际分配一致）：
        6 = b_session, 7 = b_logs, 8 = b_wake, 9 = h_face
    """

    COMPONENT_MAP = {
        6: "会话",
        7: "日志",
        8: "唤醒",
        9: "面部",
    }

    def __init__(
        self,
        app: "OctopusAssistantHMI",
        notifier: Optional[BehaviorEngineNotifier] = None,
    ) -> None:
        self.app = app
        self.notifier = notifier

    def on_touch_event(self, event: HMIEevent) -> None:
        """处理触摸事件."""
        if event.event_type != "press":
            return  # 只处理按下事件

        comp_id = event.component_id
        name = self.COMPONENT_MAP.get(comp_id, f"未知({comp_id})")
        logger.info("HMI 触摸: %s (component_id=%d)", name, comp_id)
        self.app._mark_activity()

        if comp_id == 6:
            # 会话按钮
            logger.info("触控: 新建会话")
            if not self.app.is_awake:
                self.app.wake_up()

            self.app.llm.reset()
            self.app.set_emotion(OctopusEmotion.WAVING)
            self.app.hmi.set_message_text("会话开始，请稍等...")

            # 发送开场白并获取回复
            def _do_session():
                reply = self.app.llm.chat("你好，我们开始对话吧")
                self.app.hmi.set_message_text(reply[:60])
                self.app.dialog_history.add("assistant", reply)
                self.app.tts.speak(reply)
                self.app.set_emotion(OctopusEmotion.HAPPY)
                # 3秒后恢复 caring
                time.sleep(3.0)
                self.app.set_emotion(OctopusEmotion.CARING)
            threading.Thread(target=_do_session, daemon=True).start()

            if self.notifier:
                self.notifier.notify_action("chat")

        elif comp_id == 7:
            # 日志按钮
            logger.info("触控: 查看日志")
            summary = self.app.dialog_history.get_summary(count=3)
            self.app.hmi.set_message_text(summary)
            # 5秒后清空消息
            def _clear():
                time.sleep(5.0)
                self.app.hmi.set_message_text("")
            threading.Thread(target=_clear, daemon=True).start()

        elif comp_id == 8:
            # 唤醒按钮：启动语音对话
            logger.info("触控: 唤醒对话")
            if not self.app.is_awake:
                self.app.wake_up()

            self.app.hmi.set_message_text("我在！请说话...")
            self.app.tts.speak("我在！请说话...")
            self.app.set_emotion(OctopusEmotion.CARING)

            if self.app.voice:
                self.app.voice.start()

            if self.notifier:
                self.notifier.notify_action("greet")

        elif comp_id == 9:
            # 面部热区
            if self.app.is_awake:
                logger.debug("触控: 面部区域 -> 切换表情")
                emotions = [
                    OctopusEmotion.HAPPY,
                    OctopusEmotion.WINK,
                    OctopusEmotion.SURPRISED,
                    OctopusEmotion.SHY,
                    OctopusEmotion.SAD,
                    OctopusEmotion.ANGRY,
                ]
                idx = int(time.time()) % len(emotions)
                self.app.set_emotion(emotions[idx])
            else:
                logger.debug("触控: 面部区域（未唤醒，无反应）")


# ============================================================================
# 主应用类
# ============================================================================

class OctopusAssistantHMI:
    """章鱼助手 HMI 版主应用.

    状态机:
        SLEEP        -> 显示完整章鱼，等待唤醒
        AWAKE        -> 显示 caring 表情，自动眨眼
        CONVERSATION -> 会话中，动态切换表情
    """

    def __init__(self, config: VerticalConfig, offline: bool = False) -> None:
        self.config = config
        self.running = False
        self.start_time = time.time()
        self._offline = offline

        # 状态机状态
        self._is_awake = False
        self._last_activity_time = time.time()

        # HMI 控制器
        self.hmi = HMIController(
            port=config.SERIAL_PORT,
            baudrate=config.SERIAL_BAUDRATE,
            timeout=config.SERIAL_TIMEOUT,
        )

        # 眨眼动画
        self.blink_manager = BlinkManager(
            self.hmi,
            interval_min=config.BLINK_INTERVAL_MIN,
            interval_max=config.BLINK_INTERVAL_MAX,
            duration=config.BLINK_DURATION,
        )

        # 对话历史
        self.dialog_history = DialogHistory(max_size=config.DIALOG_HISTORY_MAX_SIZE)

        # Behavior Engine 通知器
        self.notifier = BehaviorEngineNotifier(
            socket_path=getattr(config, "BEHAVIOR_ENGINE_SOCKET", "/tmp/octopus_behavior.sock")
        )
        if getattr(config, "BEHAVIOR_ENGINE_ENABLED", True):
            if self.notifier.check_available():
                logger.info("Behavior Engine 已连接: %s", self.notifier.socket_path)
            else:
                logger.warning("Behavior Engine 未运行: %s", self.notifier.socket_path)

        # OpenClaw（WebSocket 连接，用于状态同步）
        self.openclaw = OpenClawClient(
            ws_url=config.OPENCLAW_WS_URL,
            token=getattr(config, "OPENCLAW_TOKEN", ""),
            reconnect_interval=config.OPENCLAW_RECONNECT_INTERVAL,
            heartbeat_interval=config.OPENCLAW_HEARTBEAT_INTERVAL,
        )

        # 直接 LLM 客户端（绕过 OpenClaw schema 兼容问题）
        self.llm = DirectLLMClient(
            api_key=getattr(config, "ORBITAI_API_KEY", ""),
            base_url="https://aiapi.orbitai.global/v1",
            model="gpt-5.4",
        )

        # TTS 语音客户端
        self.tts = TTSClient(
            voice=getattr(config, "TTS_VOICE", "zh-CN-XiaoxiaoNeural"),
            rate=getattr(config, "TTS_RATE", "+0%"),
            enabled=getattr(config, "TTS_ENABLED", True),
        )

        # 语音输入管道（TTS 播放时自动隔绝麦克风）
        self.voice = VoicePipeline(
            on_text_callback=self._on_voice_text,
            mic_device=getattr(config, "VOICE_MIC_DEVICE", "plughw:1,0"),
        ) if getattr(config, "VOICE_ENABLED", True) else None

        # 触手爪子控制器
        self.claws = ClawController(
            port=getattr(config, "CLAW_SERIAL_PORT", "/dev/ttyAMA1"),
            baudrate=getattr(config, "CLAW_SERIAL_BAUDRATE", 115200),
        ) if getattr(config, "CLAW_ENABLED", True) else None

        # 视觉引擎 (YOLOv8 ONNX)
        self.vision = VisionEngine(
            model_path=getattr(config, "VISION_MODEL_PATH", "/home/openEuler/yolov8n-oiv7.onnx"),
            camera_index=getattr(config, "VISION_CAMERA_INDEX", 0),
            inference_interval=getattr(config, "VISION_INFERENCE_INTERVAL", 1.0),
            history_seconds=getattr(config, "VISION_HISTORY_SECONDS", 10.0),
        ) if getattr(config, "VISION_ENABLED", True) else None

        # 设置回调
        self.callbacks = OctopusCallbacks(self, notifier=self.notifier)
        self.openclaw.callbacks = self.callbacks

        # 触控
        self.touch = HMITouchHandler(self, notifier=self.notifier)
        self.hmi.register_touch_callback(self.touch.on_touch_event)

    # ------------------------------------------------------------------
    # 状态查询
    # ------------------------------------------------------------------

    @property
    def is_awake(self) -> bool:
        """是否已唤醒."""
        return self._is_awake

    # ------------------------------------------------------------------
    # 状态切换
    # ------------------------------------------------------------------

    def wake_up(self) -> None:
        """唤醒：从 SLEEP 进入 AWAKE."""
        if self._is_awake:
            logger.debug("已经是唤醒状态")
            return

        self._is_awake = True
        self._mark_activity()
        self.blink_manager.enable()
        self.set_emotion(OctopusEmotion.CARING)
        self.hmi.set_status_text("章鱼助手")
        self.hmi.set_message_text("")
        if self.vision:
            ok = self.vision.start()
            if ok:
                logger.info("[vision] 视觉引擎已启动")
            else:
                logger.error("[vision] 视觉引擎启动失败！")
        logger.info("状态切换: SLEEP -> AWAKE")

    def go_to_sleep(self) -> None:
        """休眠：从 AWAKE/CONVERSATION 回到 SLEEP."""
        if not self._is_awake:
            logger.debug("已经是休眠状态")
            return

        self._is_awake = False
        self.blink_manager.disable()
        if self.voice:
            self.voice.stop()
        self.tts.stop()
        if self.claws:
            self.claws.reset_all()
        if self.vision:
            self.vision.stop()
        self.hmi.show_sleep()
        self.hmi.set_status_text("章鱼助手")
        self.hmi.set_message_text("")
        self.dialog_history.clear()
        logger.info("状态切换: AWAKE -> SLEEP")

    def set_emotion(self, emotion: OctopusEmotion) -> None:
        """切换表情（包装器，同时更新活动时间）."""
        self._mark_activity()
        self.hmi.set_emotion(emotion)
        # 开心时触发爪子波浪动作
        if emotion == OctopusEmotion.HAPPY and self.claws:
            self.claws.happy_wave()

    def _mark_activity(self) -> None:
        """标记活动时间（用于空闲超时检测）."""
        self._last_activity_time = time.time()

    # ------------------------------------------------------------------
    # 语音对话回调
    # ------------------------------------------------------------------

    # 停止语音监听的触发词
    STOP_KEYWORDS = {"停下来", "停止", "别说了", "闭嘴", "休息", "休眠"}
    CLAW_RETRACT_KEYWORDS = {"收缩爪子", "收爪子", "握拳", "缩起来"}
    CLAW_EXTEND_KEYWORDS = {"张开爪子", "伸爪子", "展开", "打开爪子"}
    CLAW_WAVE_KEYWORDS = {"挥挥爪子", "挥手", "打招呼", "摆摆手"}
    VOLUME_UP_KEYWORDS = {"大声点", "大声一点", "音量加大", "大点声"}
    VOLUME_DOWN_KEYWORDS = {"小声点", "小声一点", "音量减小", "小点声"}
    VISION_QUERY_KEYWORDS = {
        "你现在能看到什么", "看到了什么", "有什么", "看到什么",
        "你在看什么", "描述一下", "画面里", "周围有什么",
    }

    def _on_voice_text(self, text: str) -> None:
        """语音识别到文字后的处理流程.

        1. 检查停止指令 / 爪子指令
        2. 显示用户说的话
        3. 送 LLM 获取回复
        4. 显示 + 朗读回复
        5. 继续监听下一句
        """
        if not text:
            return

        # 打断机制：如果TTS正在播放，先停止
        if self.tts.is_speaking():
            logger.info("[voice] 用户打断，停止当前播放")
            self.tts.stop()

        logger.info("[voice] 识别结果: %s", text[:40])
        self._mark_activity()

        # 1. 停止指令
        if any(kw in text for kw in self.STOP_KEYWORDS):
            logger.info("[voice] 收到停止指令: %s", text)
            self.hmi.set_message_text("好的，我休息了~")
            self.tts.speak("好的，我休息了")
            if self.voice:
                self.voice.stop()
            # 3 秒后进入休眠
            def _sleep_delay():
                time.sleep(3.0)
                self.go_to_sleep()
            threading.Thread(target=_sleep_delay, daemon=True).start()
            return

        # 2. 爪子指令（直接执行，不送 LLM）
        if any(kw in text for kw in self.CLAW_RETRACT_KEYWORDS):
            logger.info("[voice] 爪子指令: 收缩")
            if self.claws:
                self.claws.retract_all()
            self.hmi.set_message_text("收缩爪子！")
            self.tts.speak("好的，收缩爪子")
            return

        if any(kw in text for kw in self.CLAW_EXTEND_KEYWORDS):
            logger.info("[voice] 爪子指令: 张开")
            if self.claws:
                self.claws.extend_all()
            self.hmi.set_message_text("张开爪子！")
            self.tts.speak("好的，张开爪子")
            return

        if any(kw in text for kw in self.CLAW_WAVE_KEYWORDS):
            logger.info("[voice] 爪子指令: 挥手")
            if self.claws:
                self.claws.happy_wave()
            self.hmi.set_message_text("挥挥爪子~")
            self.tts.speak("你好呀")
            return

        # 3. 音量控制指令
        if any(kw in text for kw in self.VOLUME_UP_KEYWORDS):
            logger.info("[voice] 音量指令: 加大")
            os.system("amixer -c 0 set PCM 255 unmute 2>/dev/null")
            self.hmi.set_message_text("音量已调大")
            self.tts.speak("好的，音量调大了")
            return

        if any(kw in text for kw in self.VOLUME_DOWN_KEYWORDS):
            logger.info("[voice] 音量指令: 减小")
            os.system("amixer -c 0 set PCM 100 unmute 2>/dev/null")
            self.hmi.set_message_text("音量已调小")
            self.tts.speak("好的，音量调小了")
            return

        # 4. 视觉查询指令
        if any(kw in text for kw in self.VISION_QUERY_KEYWORDS):
            logger.info("[voice] 视觉查询: %s", text)
            # 尝试启动视觉引擎（如果未运行）
            if self.vision and not self.vision.is_running():
                logger.info("[vision] 尝试启动视觉引擎...")
                ok = self.vision.start()
                if not ok:
                    logger.error("[vision] 视觉引擎启动失败")
            if self.vision and self.vision.is_running():
                desc = self.vision.get_scene_description()
                self.dialog_history.add("user", text)
                self.dialog_history.add("assistant", desc)
                self.hmi.set_message_text(desc[:60])
                self.tts.speak(desc)
                self.set_emotion(OctopusEmotion.SURPRISED)
                # 3 秒后恢复 caring
                def _reset_surprised():
                    time.sleep(3.0)
                    self.set_emotion(OctopusEmotion.CARING)
                    self.hmi.set_message_text("")
                threading.Thread(target=_reset_surprised, daemon=True).start()
            else:
                self.hmi.set_message_text("摄像头未连接")
                self.tts.speak("我现在打不开摄像头呢")
            return

        # 5. 显示用户消息
        self.dialog_history.add("user", text)
        self.set_emotion(OctopusEmotion.CARING)
        self.hmi.set_message_text(f"你说: {text[:30]}")

        # 4. 获取 LLM 回复（后台线程避免阻塞录音）
        def _get_reply():
            reply = self.llm.chat(text)
            self.dialog_history.add("assistant", reply)
            self.hmi.set_message_text(reply[:60])
            self.tts.speak(reply)
            self.set_emotion(OctopusEmotion.HAPPY)
            # 等 TTS 播完
            while self.tts.is_speaking():
                time.sleep(0.2)
            # 3 秒后恢复 caring
            time.sleep(3.0)
            self.set_emotion(OctopusEmotion.CARING)
            self.hmi.set_message_text("")

        threading.Thread(target=_get_reply, daemon=True).start()

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def start(self) -> bool:
        """启动章鱼助手."""
        logger.info("=" * 50)
        logger.info("章鱼助手 HMI 版 启动中...")
        logger.info("=" * 50)

        # 1. 连接串口屏
        if not self._offline:
            logger.info("连接串口屏 %s @ %d...",
                       self.config.SERIAL_PORT, self.config.SERIAL_BAUDRATE)
            if not self.hmi.connect():
                logger.error("串口屏连接失败!")
                return False
            logger.info("串口屏连接成功")

            # 初始化屏幕
            logger.info("初始化 HMI 屏幕...")
            self.hmi.init_screen()
            time.sleep(0.5)
            logger.info("HMI 屏幕初始化完成 (page main)")
        else:
            logger.info("离线模式，跳过串口连接")

        # 2. 启动 OpenClaw
        if self.config.OPENCLAW_ENABLED and not self._offline:
            logger.info("启动 OpenClaw 连接...")
            self.openclaw.start()
            time.sleep(1.0)
            if self.openclaw.is_connected():
                logger.info("OpenClaw 已连接")
            else:
                logger.warning("OpenClaw 尚未连接，重连中...")
                self.hmi.set_conn_status("连接中...", color=48192)  # BROWN
        else:
            logger.info("OpenClaw 已禁用（离线模式）")
            self.hmi.set_conn_status("离线", color=33840)  # GRAY
            self._offline = True

        # 3. 初始状态：SLEEP（显示完整章鱼）
        if not self._offline:
            self._is_awake = False
            self.blink_manager.disable()
            self.hmi.show_sleep()
            self.hmi.set_status_text("章鱼助手")
            self.blink_manager.start()

        logger.info("=" * 50)
        logger.info("章鱼助手启动完成！")
        logger.info("模式: %s", "离线" if self._offline else "在线")
        logger.info("初始状态: SLEEP（休眠）")
        logger.info("=" * 50)

        # 4. 主循环
        self._main_loop()
        return True

    def stop(self) -> None:
        """停止章鱼助手."""
        logger.info("正在停止...")
        self.running = False
        self.blink_manager.stop()
        if self.voice:
            self.voice.stop()
        self.tts.stop()
        if self.claws:
            self.claws.close()
        if self.vision:
            self.vision.stop()
        self.openclaw.stop()
        self.hmi.disconnect()
        uptime = time.time() - self.start_time
        logger.info("运行时长: %.0f 秒", uptime)

    def _main_loop(self) -> None:
        """主循环：低频心跳 + 空闲超时检测."""
        self.running = True
        timeout_seconds = getattr(self.config, "AWAKE_TIMEOUT_SECONDS", 300.0)

        while self.running:
            time.sleep(1.0)

            # 每秒打印一次状态（调试用）
            if self.openclaw.is_connected():
                logger.debug("OpenClaw: 已连接 | HMI: %s | 状态: %s",
                            "已连接" if self.hmi.is_connected() else "断开",
                            "AWAKE" if self._is_awake else "SLEEP")
            else:
                logger.debug("OpenClaw: 未连接")

            # 空闲超时检测：AWAKE 状态下长时间无操作 -> SLEEP
            if self._is_awake and not self._offline:
                idle_time = time.time() - self._last_activity_time
                if idle_time > timeout_seconds:
                    logger.info("空闲 %.0f 秒，自动进入休眠", idle_time)
                    self.go_to_sleep()


# ============================================================================
# 命令行入口
# ============================================================================

def parse_args():
    parser = argparse.ArgumentParser(
        description="章鱼助手 HMI 版",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python3 octopus_assistant_hmi.py                  # 正常运行
  python3 octopus_assistant_hmi.py --offline        # 离线测试
  python3 octopus_assistant_hmi.py --debug          # 调试模式
        """,
    )
    parser.add_argument("--port", type=str, default="/dev/ttyAMA2")
    parser.add_argument("--baud", type=int, default=19200)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--offline", action="store_true")
    parser.add_argument(
        "--ws-url", type=str,
        default="ws://localhost:18789/openclaw",
        help="OpenClaw WebSocket 地址",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    level = "DEBUG" if args.debug else "INFO"
    setup_logging(level=level, log_file=None)

    logger.info("章鱼助手 HMI 版")
    logger.info("物理屏幕: 800x480 | HMI 单页面设计 | 指令控制")

    config = VerticalConfig(
        SERIAL_PORT=args.port,
        SERIAL_BAUDRATE=args.baud,
        OPENCLAW_WS_URL=args.ws_url,
        OPENCLAW_ENABLED=not args.offline,
    )

    app = OctopusAssistantHMI(config, offline=args.offline)

    from octopus_pkg.utils import setup_signal_handlers
    setup_signal_handlers(shutdown_callback=app.stop)

    if not app.start():
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
