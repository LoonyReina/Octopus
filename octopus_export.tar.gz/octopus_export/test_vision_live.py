#!/usr/bin/env python3
"""YOLOv8 ONNX 实时视觉测试脚本.

用法:
    sudo python3 /home/openEuler/test_vision_live.py
    # 对着摄像头放手机、杯子、书等物体
    # 按 Ctrl+C 停止
"""

import cv2
import numpy as np
import onnxruntime as ort
import time
import sys

MODEL_PATH = "/home/openEuler/yolov8n-oiv7.onnx"
CONF_THRES = 0.25  # 降低阈值以便更容易检测到
IOU_THRES = 0.45
IMG_SIZE = 640

COMMON_NAMES = {
    0: "人", 1: "男性", 2: "女性", 3: "脸", 4: "手", 5: "手臂", 6: "腿", 7: "脚",
    14: "猫", 15: "狗", 16: "马", 17: "鸟", 18: "鱼", 19: "蝴蝶", 20: "蜜蜂",
    21: "蜘蛛", 22: "蜗牛", 23: "蛇", 24: "青蛙", 25: "乌龟",
    44: "汽车", 45: "卡车", 46: "公交车", 47: "自行车", 48: "摩托车",
    49: "火车", 50: "船", 51: "飞机", 52: "直升机",
    77: "手机", 78: "笔记本电脑", 79: "平板电脑", 80: "显示器", 81: "键盘",
    82: "鼠标", 83: "遥控器", 84: "相机", 85: "耳机",
    116: "杯子", 117: "瓶子", 118: "碗", 119: "盘子", 120: "叉子",
    121: "勺子", 122: "刀",
    180: "椅子", 181: "桌子", 182: "沙发", 183: "床", 184: "柜子",
    185: "书架", 186: "台灯", 187: "窗帘", 188: "门", 189: "窗户",
    277: "书", 278: "笔", 279: "纸", 280: "包", 281: "钱包",
    282: "雨伞", 283: "眼镜", 284: "手表", 285: "帽子",
    440: "树", 441: "花", 442: "草", 443: "山", 444: "天空",
    445: "云", 446: "太阳", 447: "月亮", 448: "星星",
    476: "披萨", 477: "汉堡", 478: "三明治", 479: "热狗",
    480: "蛋糕", 481: "甜甜圈", 482: "冰淇淋", 483: "巧克力",
}


def preprocess(img, size=IMG_SIZE):
    h, w = img.shape[:2]
    scale = size / max(h, w)
    new_h, new_w = int(h * scale), int(w * scale)
    resized = cv2.resize(img, (new_w, new_h))
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    y_off = (size - new_h) // 2
    x_off = (size - new_w) // 2
    canvas[y_off:y_off+new_h, x_off:x_off+new_w] = resized
    canvas = canvas.astype(np.float32) / 255.0
    canvas = np.transpose(canvas, (2, 0, 1))
    return np.expand_dims(canvas, 0), scale, x_off, y_off


def postprocess(output, scale, x_off, y_off, conf_thres=CONF_THRES):
    output = np.squeeze(output[0]).T  # (8400, 605)
    boxes = output[:, :4]
    scores = output[:, 4:]
    class_ids = np.argmax(scores, axis=1)
    confs = np.max(scores, axis=1)

    mask = confs > conf_thres
    if not mask.any():
        return []

    boxes, confs, class_ids = boxes[mask], confs[mask], class_ids[mask]

    # 还原到原图坐标
    boxes[:, 0] = (boxes[:, 0] - x_off) / scale
    boxes[:, 1] = (boxes[:, 1] - y_off) / scale
    boxes[:, 2] /= scale
    boxes[:, 3] /= scale

    # xywh -> xyxy
    x_c, y_c, w, h = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    x1 = x_c - w / 2
    y1 = y_c - h / 2
    x2 = x_c + w / 2
    y2 = y_c + h / 2
    boxes_xyxy = np.column_stack([x1, y1, x2, y2])

    keep = cv2.dnn.NMSBoxes(
        boxes_xyxy.tolist(),
        confs.tolist(),
        conf_thres,
        IOU_THRES,
    )
    if len(keep) == 0:
        return []

    results = []
    for i in keep.flatten():
        results.append((int(class_ids[i]), float(confs[i]), boxes_xyxy[i].astype(int)))
    return results


def main():
    print("=" * 50)
    print("YOLOv8 ONNX 实时视觉测试")
    print("=" * 50)

    # 1. 加载模型
    print(f"[1/3] 加载模型: {MODEL_PATH}")
    try:
        sess = ort.InferenceSession(MODEL_PATH, providers=["CPUExecutionProvider"])
        input_name = sess.get_inputs()[0].name
        print(f"      OK | 输入: {sess.get_inputs()[0].shape}")
        print(f"      OK | 输出: {sess.get_outputs()[0].shape}")
    except Exception as e:
        print(f"      FAIL: {e}")
        sys.exit(1)

    # 2. 打开摄像头
    print("[2/3] 打开摄像头...")
    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("      FAIL: 无法打开摄像头")
        sys.exit(1)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    print(f"      OK | 分辨率: {cap.get(cv2.CAP_PROP_FRAME_WIDTH):.0f}x{cap.get(cv2.CAP_PROP_FRAME_HEIGHT):.0f}")

    # 3. 实时推理循环
    print("[3/3] 开始实时推理 (按 Ctrl+C 停止)")
    print("-" * 50)
    print("提示: 对着摄像头放手机、杯子、书等常见物体")
    print("-" * 50)

    frame_count = 0
    last_report = 0
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[warn] 读取摄像头失败")
                time.sleep(0.1)
                continue

            blob, scale, x_off, y_off = preprocess(frame)
            outputs = sess.run(None, {input_name: blob})
            dets = postprocess(outputs, scale, x_off, y_off)

            frame_count += 1
            now = time.time()

            if dets:
                names = []
                for cls_id, conf, box in dets[:5]:
                    name = COMMON_NAMES.get(cls_id, f"物体{cls_id}")
                    names.append(f"{name}({conf:.2f})")
                print(f"[帧{frame_count}] 检测到: {', '.join(names)}")
                last_report = now
            elif now - last_report > 3.0:
                print(f"[帧{frame_count}] 未检测到物体 (请把物体放到摄像头前)")
                last_report = now

            time.sleep(0.3)  # 限制打印频率
    except KeyboardInterrupt:
        print("\n停止")
    finally:
        cap.release()
        print("摄像头已释放")


if __name__ == "__main__":
    main()
