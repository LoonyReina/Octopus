# 章鱼助手 HMI 版 (Octopus Assistant)

基于 TJC HMI 串口屏的章鱼助手，运行在 Orange Pi Kunpeng Pro 上。

## 功能

- TJC HMI 串口屏表情切换（单页面 pic 切换）
- OpenClaw WebSocket 连接
- 语音输入：麦克风 → VAD → 腾讯云 ASR
- LLM 对话：orbitai API (gpt-5.4)
- TTS 输出：edge-tts (在线) + espeak-ng (离线 fallback)
- 触手爪子控制：STM32 RT1064 舵机
- YOLOv8 ONNX 实时视觉识别
- 自动眨眼动画
- 唤醒/休眠状态机

## 目录结构

```
octopus_assistant/
  config_vertical.py          # 全局配置
  octopus_pkg/
    hmi_controller.py          # HMI 串口控制器 + 眨眼管理
    openclaw_vertical.py       # OpenClaw WebSocket 客户端
    tts_client.py              # TTS 队列播放器
    voice_pipeline.py          # 录音 + VAD + 腾讯 ASR
    claw_controller.py         # STM32 舵机控制
    vision_engine.py           # YOLOv8 ONNX 推理
    utils.py                   # 工具函数
    tjc_screen.py              # 串口屏协议

octopus_assistant_new/
  octopus_assistant_hmi.py     # 主程序入口
  octopus_web_app.py           # Web 界面

test_vision_live.py            # YOLO 摄像头独立测试
requirements.txt               # Python 依赖
```

## 运行

```bash
cd octopus_assistant_new
sudo python3 octopus_assistant_hmi.py
```

调试模式：
```bash
sudo python3 octopus_assistant_hmi.py --debug
```

## 语音指令

| 指令 | 效果 |
|------|------|
| "大声点" | 调大音量 |
| "小声点" | 调小音量 |
| "收缩爪子" | 舵机闭合 |
| "张开爪子" | 舵机展开 |
| "挥挥爪子" | 波浪动作 |
| "你现在能看到什么" | YOLO 视觉描述 |
| "停下来" / "休息" | 进入休眠 |

## 硬件

- Orange Pi Kunpeng Pro
- TJC 串口屏 (480x272, /dev/ttyAMA2 @ 19200)
- Jieli USB 麦克风 (plughw:1,0)
- 扬声器
- STM32 RT1064 舵机控制器 (/dev/ttyAMA1 @ 115200)
- USB 摄像头 (/dev/video0 or /dev/video1)

## 配置

编辑 `octopus_assistant/config_vertical.py`：
- 串口屏端口
- 摄像头索引
- YOLO 模型路径
- OpenClaw / TTS / 语音参数

## 依赖

```bash
pip install -r requirements.txt
# 系统依赖
sudo apt install ffmpeg espeak-ng arecord
```
