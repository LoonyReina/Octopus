"""章鱼助手 — 竖屏版本全局配置.

适配TJC串口屏竖屏挂载（物理480x272，逆时针旋转90°后为272x480竖屏体验）。
实际硬件为480x272分辨率，通过软件旋转变为竖屏交互。
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class VerticalConfig:
    """章鱼助手竖屏版本全局配置.

    屏幕物理分辨率480x272，逆时针旋转90°使用：
    - 物理宽度 480 → 旋转后成为竖屏高度
    - 物理高度 272 → 旋转后成为竖屏宽度
    - 逻辑设计空间: 272x480 (竖屏UI设计坐标)
    """

    # ========================================================================
    # 串口配置（鲲鹏Pro实际可用串口）
    # 注意：/dev/ttyS3 在本系统上无法配置（I/O error），
    #       实际可用的是 /dev/ttyAMA2，波特率 115200。
    # ========================================================================
    SERIAL_PORT: str = "/dev/ttyAMA2"
    SERIAL_BAUDRATE: int = 19200
    SERIAL_TIMEOUT: float = 1.0

    # ========================================================================
    # 屏幕参数
    # ========================================================================
    SCREEN_WIDTH: int = 272
    """逻辑竖屏宽度（像素）— UI设计空间"""

    SCREEN_HEIGHT: int = 480
    """逻辑竖屏高度（像素）— UI设计空间"""

    PHYSICAL_WIDTH: int = 800
    """物理屏幕实际宽度（像素）— 水平方向"""

    PHYSICAL_HEIGHT: int = 480
    """物理屏幕实际高度（像素）— 垂直方向"""

    SCREEN_PAGES: int = 11
    FACTORY_PAGE_COUNT: int = 6

    # ========================================================================
    # 章鱼面部布局参数（逻辑竖屏坐标）
    # ========================================================================
    FACE_CENTER_X: int = 136
    """面部中心X坐标（屏幕宽度中点）"""

    FACE_CENTER_Y: int = 200
    """面部中心Y坐标（偏上，给按钮留空间）"""

    FACE_RADIUS: int = 75
    """面部基础半径"""

    # ========================================================================
    # 触手布局（边缘触手）
    # ========================================================================
    TENTACLE_COUNT: int = 6
    """边缘触手数量（左右各3条）"""

    TENTACLE_SEGMENTS: int = 5
    """每条触手的贝塞尔段数"""

    TENTACLE_MAX_LENGTH: int = 100
    """触手最大长度"""

    # ========================================================================
    # 动画参数
    # ========================================================================
    ANIMATION_FPS: int = 10
    BREATH_PERIOD: float = 3.0
    BREATH_PERIOD_LAZY: float = 5.0
    BLINK_INTERVAL_MIN: float = 2.0
    BLINK_INTERVAL_MAX: float = 4.0
    BLINK_DURATION: float = 0.5          # 眨眼持续时间（秒）
    TENTACLE_SWING_PERIOD: float = 1.5
    EMOTION_TRANSITION_TIME: float = 0.3

    # ========================================================================
    # 唤醒/休眠状态机配置
    # ========================================================================
    AWAKE_TIMEOUT_SECONDS: float = 300.0  # 空闲多久后自动回到休眠（秒）
    DIALOG_HISTORY_MAX_SIZE: int = 50     # 对话历史最大条数

    # ========================================================================
    # 触控参数
    # ========================================================================
    TOUCH_LONG_PRESS_MS: int = 800
    TOUCH_SWIPE_THRESHOLD: int = 50
    TOUCH_DOUBLE_TAP_MS: int = 300

    # ========================================================================
    # 按钮布局（竖屏底部 → 旋转后位于右侧）
    # ========================================================================
    BUTTON_COUNT: int = 3
    BUTTON_WIDTH: int = 220
    BUTTON_HEIGHT: int = 44
    BUTTON_GAP: int = 12
    BUTTON_AREA_Y: int = 360
    """按钮区域起始Y坐标（逻辑竖屏）"""

    # ========================================================================
    # OpenClaw 联动配置
    # ========================================================================
    OPENCLAW_ENABLED: bool = True
    OPENCLAW_WS_URL: str = "ws://localhost:18789/openclaw"
    OPENCLAW_HTTP_URL: str = "http://localhost:18789/api"
    OPENCLAW_TOKEN: str = "0778c5d127597115df6b1b10194069ceb173b3d725f6d04e"
    ORBITAI_API_KEY: str = "sk-4a4c793b607734337d10522f4af7073f2358c1095293cf77cc1a8a3c84a7e661"
    OPENCLAW_PROTOCOL: str = "websocket"
    OPENCLAW_RECONNECT_INTERVAL: float = 5.0
    OPENCLAW_HEARTBEAT_INTERVAL: float = 30.0

    # ========================================================================
    # Behavior Engine 联动配置
    # ========================================================================
    BEHAVIOR_ENGINE_ENABLED: bool = True
    BEHAVIOR_ENGINE_SOCKET: str = "/tmp/octopus_behavior.sock"

    # ========================================================================
    # TTS 语音配置
    # ========================================================================
    TTS_ENABLED: bool = True
    TTS_VOICE: str = "zh-CN-XiaoxiaoNeural"
    TTS_RATE: str = "+0%"

    # ========================================================================
    # 语音输入配置
    # ========================================================================
    VOICE_ENABLED: bool = True
    VOICE_MIC_DEVICE: str = "plughw:1,0"

    # ========================================================================
    # 触手爪子配置 (STM32 RT1064)
    # ========================================================================
    CLAW_ENABLED: bool = True
    CLAW_SERIAL_PORT: str = "/dev/ttyAMA1"
    CLAW_SERIAL_BAUDRATE: int = 115200

    # ========================================================================
    # 表情库配置
    # ========================================================================
    EMOTION_COUNT: int = 8
    EMOTION_FRAME_COUNT: int = 8

    # ========================================================================
    # 日志配置
    # ========================================================================
    LOG_LEVEL: str = "INFO"
    LOG_FILE: Optional[str] = "/var/log/octopus_assistant.log"
    LOG_FORMAT: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    # ========================================================================
    # 性能保护
    # ========================================================================
    MAX_CMD_QUEUE_SIZE: int = 100
    MAX_CMDS_PER_FRAME: int = 60
    CPU_USAGE_THRESHOLD: float = 80.0
    LOW_FPS_MODE: int = 6

    # ========================================================================
    # 图片模式配置
    # ========================================================================
    PICTURE_MODE_ENABLED: bool = True
    PICTURE_EMOTION_BASE_ID: int = 0

    # ========================================================================
    # 视觉引擎配置 (YOLOv8 ONNX)
    # ========================================================================
    VISION_ENABLED: bool = True
    VISION_MODEL_PATH: str = "/home/openEuler/yolov8n-oiv7.onnx"
    VISION_CAMERA_INDEX: int = 1
    VISION_INFERENCE_INTERVAL: float = 1.0
    VISION_HISTORY_SECONDS: float = 10.0

    def as_dict(self) -> dict:
        return {
            field.name: getattr(self, field.name)
            for field in self.__dataclass_fields__.values()
        }

    def replace(self, **kwargs) -> "VerticalConfig":
        from dataclasses import replace
        return replace(self, **kwargs)


# 兼容旧代码的别名
Config = VerticalConfig
