"""章鱼助手 — 陶晶驰串口屏交互动画系统.

基于香橙派鲲鹏Pro + 陶晶驰TJC8048X570触控串口屏(480x272)的
章鱼主题智能硬件交互系统。

核心模块:
    - tjc_screen:      串口屏通信核心 (TJCScreen)
    - page_manager:    页面管理器 (PageManager)
    - octopus_renderer: 章鱼动画渲染器 (OctopusRenderer, Emotion)
    - touch_handler:   触控交互处理器 (TouchHandler, GestureType)
    - openclaw_bridge: OpenClaw智能体联动 (OpenClawBridge, UserStatus, DeviceCommand)
    - utils:           通用工具函数

快速启动::
    from octopus_pkg import TJCScreen, Config
    from octopus_pkg import setup_logging

    setup_logging("INFO")
    screen = TJCScreen()
    screen.connect()
    screen.cls(0x10A2)  # 深海蓝背景
"""

__version__ = "1.0.0"
__author__ = "章鱼助手开发团队"

# 便捷导入 — 从各模块导出核心类
from .tjc_screen import TJCScreen, TouchEvent, rgb_to_565
from .page_manager import PageManager
from .octopus_renderer import Emotion, TentacleState, OctopusRenderer
from .touch_handler import GestureType, TouchAction, TouchHandler
from .openclaw_bridge import (
    OpenClawBridge,
    UserStatus,
    DeviceCommand,
    ProtocolType,
)
from .utils import (
    setup_logging,
    setup_signal_handlers,
    get_cpu_usage,
    FPSCounter,
    format_user_status_text,
    emotion_from_status,
    clamp_value,
    lerp,
)

__all__ = [
    # 版本信息
    "__version__",
    # 串口屏通信
    "TJCScreen",
    "TouchEvent",
    "rgb_to_565",
    # 页面管理
    "PageManager",
    # 动画渲染
    "Emotion",
    "TentacleState",
    "OctopusRenderer",
    # 触控交互
    "GestureType",
    "TouchAction",
    "TouchHandler",
    # OpenClaw联动
    "OpenClawBridge",
    "UserStatus",
    "DeviceCommand",
    "ProtocolType",
    # 工具函数
    "setup_logging",
    "setup_signal_handlers",
    "get_cpu_usage",
    "FPSCounter",
    "format_user_status_text",
    "emotion_from_status",
    "clamp_value",
    "lerp",
]
