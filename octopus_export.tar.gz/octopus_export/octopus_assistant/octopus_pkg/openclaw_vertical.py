"""OpenClaw WebSocket 联动模块 — 章鱼助手竖屏版本.

实现与 OpenClaw 网关的实时双向通信：
- 接收会话状态、回复内容、情绪指令
- 发送触控按钮事件
- 同步表情切换
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("octopus.openclaw")

# ============================================================================
# 消息类型定义
# ============================================================================

class MessageType(Enum):
    """消息类型枚举."""
    # 下行（OpenClaw → 串口屏）
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    USER_MESSAGE = "user_message"
    ASSISTANT_REPLY = "assistant_reply"
    EMOTION_UPDATE = "emotion_update"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    LOG = "log"
    
    # 上行（串口屏 → OpenClaw）
    BUTTON_PRESS = "button_press"
    NEW_SESSION = "new_session"
    VIEW_LOGS = "view_logs"
    WAKE_CHAT = "wake_chat"
    SETTINGS = "settings"


@dataclass
class OpenClawMessage:
    """OpenClaw 消息数据结构."""
    type: str
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    session_id: Optional[str] = None


# ============================================================================
# 状态同步回调接口
# ============================================================================

class OpenClawCallbacks:
    """回调接口定义."""
    
    def on_emotion_change(self, emotion: str) -> None:
        """表情变化回调."""
        pass
    
    def on_session_start(self, session_id: str) -> None:
        """会话开始回调."""
        pass
    
    def on_session_end(self) -> None:
        """会话结束回调."""
        pass
    
    def on_user_message(self, text: str) -> None:
        """用户消息回调."""
        pass
    
    def on_assistant_reply(self, text: str) -> None:
        """助手回复回调."""
        pass
    
    def on_connection_change(self, connected: bool) -> None:
        """连接状态变化回调."""
        pass
    
    def on_error(self, error: str) -> None:
        """错误回调."""
        pass


# ============================================================================
# WebSocket 客户端
# ============================================================================

class OpenClawClient:
    """OpenClaw WebSocket 客户端.
    
    特性：
    - 自动重连（指数退避）
    - 心跳保活
    - 消息队列
    - 线程安全
    """
    
    def __init__(
        self,
        ws_url: str = "ws://localhost:18789/openclaw",
        token: str = "",
        callbacks: Optional[OpenClawCallbacks] = None,
        reconnect_interval: float = 5.0,
        heartbeat_interval: float = 30.0,
    ) -> None:
        self.ws_url = ws_url
        self._token = token
        self.callbacks = callbacks or OpenClawCallbacks()
        self.reconnect_interval = reconnect_interval
        self.heartbeat_interval = heartbeat_interval

        # 状态
        self._connected = False
        self._running = False
        self._ws = None
        self._session_id: Optional[str] = None
        self._hello_ok: Optional[Dict[str, Any]] = None

        # 线程
        self._thread: Optional[threading.Thread] = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # 锁
        self._lock = threading.Lock()

        # 消息队列
        self._send_queue: List[OpenClawMessage] = []
        self._queue_lock = threading.Lock()

        logger.info("OpenClawClient 初始化: %s", ws_url)
    
    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------
    
    def start(self) -> None:
        """启动客户端."""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._stop_event.clear()
        
        # 启动连接线程
        self._thread = threading.Thread(
            target=self._connection_loop,
            name="OpenClaw-WS",
            daemon=True,
        )
        self._thread.start()
        
        logger.info("OpenClaw 客户端已启动")
    
    def stop(self) -> None:
        """停止客户端."""
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._stop_event.set()
        
        # 关闭连接
        self._close_ws()
        
        # 等待线程结束
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        
        logger.info("OpenClaw 客户端已停止")
    
    # ------------------------------------------------------------------
    # 连接管理
    # ------------------------------------------------------------------
    
    def _connection_loop(self) -> None:
        """连接循环（带重连）."""
        retry_count = 0
        max_retry_interval = 60.0

        while self._running and not self._stop_event.is_set():
            try:
                self._connect()
                retry_count = 0  # 连接成功，重置重试计数
            except Exception as e:
                logger.error("连接失败: %s", e)
                retry_count += 1

            # 连接断开或失败后，统一等待再重连，防止 CPU 空转
            if not self._running or self._stop_event.is_set():
                break
            interval = min(
                self.reconnect_interval * (2 ** min(retry_count, 5)),
                max_retry_interval,
            )
            logger.info("将在 %.1f 秒后重连...", interval)
            if self._stop_event.wait(interval):
                break
    
    def _connect(self) -> None:
        """建立 WebSocket 连接并完成 OpenClaw 认证握手."""
        try:
            import websocket
        except ImportError:
            logger.error("需要安装 websocket-client: pip3 install websocket-client")
            return

        logger.info("正在连接 OpenClaw: %s", self.ws_url)

        try:
            ws = websocket.create_connection(self.ws_url, timeout=10)

            # 1. 接收 challenge
            challenge = ws.recv()
            data = json.loads(challenge)
            if data.get("event") != "connect.challenge":
                logger.error("期望 challenge，收到: %s", data)
                ws.close()
                return
            nonce = data["payload"]["nonce"]
            logger.debug("收到认证 challenge, nonce=%s", nonce)

            # 2. 发送 connect
            ws.send(json.dumps({
                "type": "req", "id": self._gen_id(), "method": "connect",
                "params": {
                    "minProtocol": 3, "maxProtocol": 3,
                    "client": {"id": "gateway-client", "version": "2.0.0", "platform": "linux", "mode": "backend"},
                    "caps": [],
                    "auth": {"token": self._token},
                    "role": "operator", "scopes": [],
                }
            }))

            # 3. 接收 hello-ok
            hello = ws.recv()
            hello_data = json.loads(hello)
            if not hello_data.get("ok"):
                err = hello_data.get("error", {}).get("message", "unknown")
                logger.error("OpenClaw 认证失败: %s", err)
                ws.close()
                return

            logger.info("OpenClaw 认证成功: protocol=%s",
                       hello_data.get("payload", {}).get("protocol"))
            self._hello_ok = hello_data.get("payload", {})
            self._ws = ws
            self._connected = True
            self.callbacks.on_connection_change(True)

            # 4. 消息接收循环
            self._receive_loop(ws)

        except Exception as e:
            logger.error("连接异常: %s", e)
        finally:
            self._connected = False
            if self._ws:
                try:
                    self._ws.close()
                except Exception:
                    pass
                self._ws = None
            self.callbacks.on_connection_change(False)
    
    def _close_ws(self) -> None:
        """关闭 WebSocket 连接."""
        if self._ws:
            try:
                self._ws.close()
            except Exception:
                pass
            self._ws = None

        self._connected = False
        self.callbacks.on_connection_change(False)

    def _receive_loop(self, ws) -> None:
        """消息接收循环."""
        import websocket as ws_lib
        while self._running and self._connected:
            try:
                ws.settimeout(1.0)
                msg = ws.recv()
                if msg:
                    self._on_ws_message(ws, msg)
            except ws_lib.WebSocketTimeoutException:
                continue
            except Exception as e:
                logger.error("接收异常: %s", e)
                break

    # ------------------------------------------------------------------
    # WebSocket 回调
    # ------------------------------------------------------------------

    def _gen_id(self) -> str:
        """生成请求 ID."""
        import uuid
        return str(uuid.uuid4())[:8]

    def _on_ws_open(self, ws) -> None:
        """WebSocket 打开回调 — 等待服务器发送 connect.challenge."""
        logger.info("OpenClaw WebSocket 已连接，等待认证 challenge...")
        # challenge 会通过 _on_ws_message_auth 接收

    def _on_ws_message_auth(self, ws, message: str) -> None:
        """认证阶段的消息处理."""
        try:
            data = json.loads(message)
        except json.JSONDecodeError:
            logger.error("认证阶段消息解析失败: %s", message[:100])
            ws.close()
            return

        if self._auth_state == "idle":
            # 等待 connect.challenge
            if data.get("event") == "connect.challenge":
                nonce = data.get("payload", {}).get("nonce", "")
                logger.debug("收到认证 challenge, nonce=%s", nonce)

                connect_req = {
                    "type": "req",
                    "id": self._gen_id(),
                    "method": "connect",
                    "params": {
                        "minProtocol": 3,
                        "maxProtocol": 3,
                        "client": {
                            "id": "gateway-client",
                            "version": "2.0.0",
                            "platform": "linux",
                            "mode": "backend",
                        },
                        "caps": [],
                        "auth": {"token": self._token},
                        "role": "operator",
                        "scopes": [],
                    },
                }
                ws.send(json.dumps(connect_req))
                self._auth_state = "waiting_hello"
            else:
                logger.warning("认证阶段收到非 challenge 消息: %s", data.get("event", "unknown"))

        elif self._auth_state == "waiting_hello":
            # 等待 hello-ok 响应
            if data.get("type") == "res":
                if data.get("ok"):
                    logger.info("OpenClaw 认证成功: protocol=%s",
                               data.get("payload", {}).get("protocol"))
                    self._hello_ok = data.get("payload", {})
                    self._auth_state = "connected"
                    self._connected = True
                    self.callbacks.on_connection_change(True)
                    # 切换到正常消息处理
                    self._ws.on_message = self._on_ws_message
                    # 启动心跳
                    self._start_heartbeat()
                else:
                    err = data.get("error", {}).get("message", "unknown")
                    logger.error("OpenClaw 认证失败: %s", err)
                    ws.close()
            else:
                logger.debug("等待 hello-ok 时收到: %s", data.get("type"))
    
    def _on_ws_message(self, ws, message: str) -> None:
        """WebSocket 消息回调."""
        try:
            data = json.loads(message)
            self._handle_message(data)
        except json.JSONDecodeError as e:
            logger.error("消息解析失败: %s", e)
        except Exception as e:
            logger.exception("消息处理异常: %s", e)
    
    def _on_ws_error(self, ws, error) -> None:
        """WebSocket 错误回调."""
        logger.error("WebSocket 错误: %s", error)
        self.callbacks.on_error(str(error))
    
    def _on_ws_close(self, ws, close_status_code, close_msg) -> None:
        """WebSocket 关闭回调."""
        logger.info("WebSocket 已关闭: code=%s, msg=%s", close_status_code, close_msg)
        self._connected = False
        self.callbacks.on_connection_change(False)
        
        # 停止心跳
        self._stop_heartbeat()
    
    # ------------------------------------------------------------------
    # 消息处理
    # ------------------------------------------------------------------
    
    def _handle_message(self, data: Dict[str, Any]) -> None:
        """处理收到的消息（适配 OpenClaw 协议 v3）."""
        msg_type = data.get("type", "")
        payload = data.get("payload", {})

        if msg_type == "event":
            event_name = data.get("event", "")
            logger.debug("收到事件: %s", event_name)

            if event_name == "health":
                # health 事件，无需处理
                pass
            elif event_name == "heartbeat":
                # 服务器心跳，响应 pong
                self._send_heartbeat_response()
            elif event_name == "chat":
                # chat 事件：可能包含对话内容
                text = payload.get("text", "")
                if text:
                    self.callbacks.on_assistant_reply(text)
            elif event_name == "session.message":
                # 会话消息
                text = payload.get("text", "")
                role = payload.get("role", "")
                if role == "user":
                    self.callbacks.on_user_message(text)
                elif role == "assistant":
                    self.callbacks.on_assistant_reply(text)
            elif event_name == "agent":
                # agent 事件
                text = payload.get("text", "")
                if text:
                    self.callbacks.on_assistant_reply(text)
            elif event_name == "presence":
                # 在线状态变化
                pass
            return

        if msg_type == "res":
            # 请求响应
            req_id = data.get("id", "")
            ok = data.get("ok", False)
            if not ok:
                err = data.get("error", {})
                logger.warning("请求 %s 失败: %s", req_id, err.get("message", ""))
            return

        # 兼容旧协议的消息类型
        session_id = data.get("session_id")
        logger.debug("收到消息: type=%s", msg_type)

        if msg_type == MessageType.SESSION_START.value:
            self._session_id = session_id
            self.callbacks.on_session_start(session_id or "")

        elif msg_type == MessageType.SESSION_END.value:
            self._session_id = None
            self.callbacks.on_session_end()

        elif msg_type == MessageType.USER_MESSAGE.value:
            text = payload.get("text", "")
            self.callbacks.on_user_message(text)
            self.callbacks.on_emotion_change("caring")

        elif msg_type == MessageType.ASSISTANT_REPLY.value:
            text = payload.get("text", "")
            emotion = payload.get("emotion", "happy")
            self.callbacks.on_assistant_reply(text)
            self.callbacks.on_emotion_change(emotion)

        elif msg_type == MessageType.EMOTION_UPDATE.value:
            emotion = payload.get("emotion", "caring")
            self.callbacks.on_emotion_change(emotion)

        elif msg_type == MessageType.ERROR.value:
            error_msg = payload.get("message", "未知错误")
            self.callbacks.on_error(error_msg)
            self.callbacks.on_emotion_change("sad")

        elif msg_type == MessageType.HEARTBEAT.value:
            self._send_heartbeat_response()

        elif msg_type == MessageType.LOG.value:
            level = payload.get("level", "info")
            message = payload.get("message", "")
            logger.info("[OpenClaw] %s: %s", level, message)
    
    # ------------------------------------------------------------------
    # 发送消息
    # ------------------------------------------------------------------
    
    def send_button_press(self, button_id: int, button_label: str) -> None:
        """发送按钮按下事件."""
        self._send_message(OpenClawMessage(
            type=MessageType.BUTTON_PRESS.value,
            payload={
                "button_id": button_id,
                "button_label": button_label,
            },
            session_id=self._session_id,
        ))
    
    def send_new_session(self) -> None:
        """请求新建会话."""
        self._send_message(OpenClawMessage(
            type=MessageType.NEW_SESSION.value,
        ))

    def send_view_logs(self) -> None:
        """请求查看日志."""
        self._send_message(OpenClawMessage(
            type=MessageType.VIEW_LOGS.value,
        ))

    def send_wake_chat(self) -> None:
        """请求唤醒对话."""
        self._send_message(OpenClawMessage(
            type=MessageType.WAKE_CHAT.value,
        ))

    def send_chat_message(self, text: str) -> bool:
        """发送聊天消息（WebSocket 方式）."""
        req_id = self._gen_id()
        return self._send_raw_json({
            "type": "req",
            "id": req_id,
            "method": "agent",
            "params": {"message": text},
        })

    # ------------------------------------------------------------------
    # CLI Fallback
    # ------------------------------------------------------------------

    def send_message_via_cli(self, text: str, agent: str = "main") -> Optional[str]:
        """通过 CLI 发送消息并返回回复（WebSocket 不可用时 fallback）.

        Returns:
            助手回复文本，失败返回 None
        """
        import subprocess
        try:
            cmd = [
                "docker", "exec", "-i", "octopus_openclaw",
                "openclaw", "agent", "--agent", agent,
                "--message", text, "--json",
            ]
            if self._session_id:
                cmd.extend(["--session-id", self._session_id])

            logger.info("CLI 调用: %s", text[:30])
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=60
            )
            if result.returncode != 0:
                logger.warning("CLI 错误: %s", result.stderr[:100])
                return None

            data = json.loads(result.stdout)
            # 提取 session ID
            meta = data.get("result", {}).get("meta", {})
            sid = meta.get("agentMeta", {}).get("sessionId")
            if sid:
                self._session_id = sid

            # 提取回复文本
            payloads = data.get("result", {}).get("payloads", [])
            for p in payloads:
                reply = p.get("text", "")
                if reply:
                    logger.info("CLI 回复: %s", reply[:50])
                    return reply
            return None
        except Exception as e:
            logger.error("CLI 调用失败: %s", e)
            return None
    
    def _send_message(self, msg: OpenClawMessage) -> None:
        """发送消息."""
        if not self._connected or not self._ws:
            logger.warning("未连接，消息已丢弃: %s", msg.type)
            return
        try:
            data = {
                "type": msg.type,
                "payload": msg.payload,
                "timestamp": msg.timestamp,
            }
            if msg.session_id:
                data["session_id"] = msg.session_id
            self._ws.send(json.dumps(data))
            logger.debug("已发送: %s", msg.type)
        except Exception as e:
            logger.error("发送失败: %s", e)

    def _send_raw_json(self, data: Dict[str, Any]) -> bool:
        """发送原始 JSON（用于 req 类型消息）."""
        if not self._connected or not self._ws:
            logger.warning("未连接，消息已丢弃: %s", data.get("method", "unknown"))
            return False
        try:
            self._ws.send(json.dumps(data))
            logger.debug("已发送 req: %s", data.get("method"))
            return True
        except Exception as e:
            logger.error("发送失败: %s", e)
            return False

    def _send_heartbeat_response(self) -> None:
        """发送心跳响应（OpenClaw 协议 v3）."""
        self._send_raw_json({
            "type": "event",
            "event": "heartbeat",
            "payload": {"status": "ok"},
        })
    
    # ------------------------------------------------------------------
    # 心跳
    # ------------------------------------------------------------------
    
    def _start_heartbeat(self) -> None:
        """启动心跳线程（OpenClaw 不需要客户端主动心跳）."""
        pass

    def _stop_heartbeat(self) -> None:
        """停止心跳."""
        pass
    
    # ------------------------------------------------------------------
    # 状态查询
    # ------------------------------------------------------------------
    
    def is_connected(self) -> bool:
        """是否已连接."""
        return self._connected
    
    def get_session_id(self) -> Optional[str]:
        """获取当前会话ID."""
        return self._session_id


# ============================================================================
# 便捷工厂函数
# ============================================================================

def create_openclaw_client(
    ws_url: str,
    callbacks: OpenClawCallbacks,
) -> OpenClawClient:
    """创建 OpenClaw 客户端."""
    return OpenClawClient(ws_url=ws_url, callbacks=callbacks)
