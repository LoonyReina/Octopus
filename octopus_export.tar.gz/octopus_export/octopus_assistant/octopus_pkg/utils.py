"""章鱼助手 — 通用工具函数.

提供日志配置、信号处理、性能监控等跨模块通用功能。
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import time
from typing import Callable, Optional


def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = "/var/log/octopus_assistant.log",
    fmt: Optional[str] = None,
) -> logging.Logger:
    """配置章鱼助手的日志系统.

    同时输出到控制台和日志文件（如指定）。

    Args:
        level: 日志级别字符串（"DEBUG"/"INFO"/"WARNING"/"ERROR"）.
        log_file: 日志文件路径，None 则仅控制台输出.
        fmt: 自定义日志格式，None 则使用默认格式.

    Returns:
        根日志器实例.
    """
    if fmt is None:
        fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]

    if log_file:
        # 确保日志目录存在
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir, exist_ok=True)
            except OSError:
                pass
        try:
            file_handler = logging.FileHandler(log_file, encoding="utf-8")
            handlers.append(file_handler)
        except OSError as e:
            logging.warning("无法创建日志文件 %s: %s", log_file, e)

    logging.basicConfig(
        level=numeric_level,
        format=fmt,
        handlers=handlers,
        force=True,
    )

    logger = logging.getLogger("octopus")
    logger.setLevel(numeric_level)
    return logger


def setup_signal_handlers(
    shutdown_callback: Optional[Callable[[], None]] = None,
) -> None:
    """配置进程信号处理器，实现优雅退出.

    捕获 SIGINT(Ctrl+C) 和 SIGTERM(systemctl stop)，调用清理回调。

    Args:
        shutdown_callback: 退出前执行的清理函数.
    """

    def _signal_handler(signum: int, frame) -> None:
        sig_name = signal.Signals(signum).name
        logging.getLogger("octopus").info(
            "收到信号 %s (%d)，开始优雅退出...", sig_name, signum
        )
        if shutdown_callback:
            try:
                shutdown_callback()
            except Exception as e:
                logging.getLogger("octopus").error("清理回调异常: %s", e)
        # 强制终止所有线程（包括非守护线程），确保不会 hang 住
        os._exit(0)

    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)
    logging.getLogger("octopus").debug("信号处理器已注册 (SIGINT, SIGTERM)")


def get_cpu_usage() -> float:
    """获取当前进程CPU使用率（%）.

    需要 psutil 库，未安装时返回0.0.

    Returns:
        CPU使用率百分比，范围 0.0-100.0.
    """
    try:
        import psutil
        process = psutil.Process(os.getpid())
        return process.cpu_percent(interval=0.1)
    except ImportError:
        return 0.0


def get_uptime(start_time: float) -> str:
    """计算运行时长.

    Args:
        start_time: 程序启动时间（time.time()）.

    Returns:
        格式化的运行时长字符串，如 "01:23:45".
    """
    elapsed = time.time() - start_time
    hours = int(elapsed // 3600)
    minutes = int((elapsed % 3600) // 60)
    seconds = int(elapsed % 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def format_user_status_text(
    steps: Optional[int] = None,
    meetings: Optional[int] = None,
    emotion: Optional[str] = None,
    fatigue: Optional[int] = None,
) -> str:
    """将用户状态数据格式化为显示文本.

    Args:
        steps: 今日步数.
        meetings: 今日会议数.
        emotion: 检测到的情绪.
        fatigue: 疲劳等级 0-10.

    Returns:
        状态文字，如 "步数15000|会议8场|状态:疲惫".
    """
    parts = []
    if steps is not None:
        parts.append(f"步数{steps}")
    if meetings is not None:
        parts.append(f"会议{meetings}场")
    if emotion:
        parts.append(f"状态:{emotion}")
    elif fatigue is not None:
        fatigue_labels = {0: "精神", 3: "正常", 6: "疲惫", 8: "极累"}
        label = "未知"
        for threshold, lbl in sorted(fatigue_labels.items()):
            if fatigue >= threshold:
                label = lbl
        parts.append(f"疲劳:{label}")
    return "|".join(parts) if parts else "等待状态数据..."


def emotion_from_status(status: dict) -> str:
    """从用户状态数据推断章鱼情绪.

    映射规则:
        - 疲劳等级>=7 或 步数>12000 → "tired"
        - 会议数>=6 或 压力等级>=7 → "busy"
        - 检测到的情绪为 "happy" → "happy"
        - 检测到的情绪为 "sad"/"tired" → "tired"
        - 默认 → "caring"

    Args:
        status: 包含 motion_steps, work_meetings, emotion_detected,
                fatigue_level, stress_level 的字典.

    Returns:
        情绪字符串，对应 Emotion 枚举的 value.
    """
    fatigue = status.get("fatigue_level", 0) or 0
    stress = status.get("stress_level", 0) or 0
    steps = status.get("motion_steps", 0) or 0
    meetings = status.get("work_meetings", 0) or 0
    detected = (status.get("emotion_detected") or "").lower()

    if fatigue >= 7 or steps > 12000:
        return "tired"
    if meetings >= 6 or stress >= 7:
        return "busy"
    if detected == "happy":
        return "happy"
    if detected in ("sad", "tired", "exhausted"):
        return "tired"
    if detected == "surprised":
        return "surprised"
    # 默认：关心模式
    return "caring"


def clamp_value(value: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """将数值限制在指定范围内.

    Args:
        value: 输入值.
        min_val: 最小值.
        max_val: 最大值.

    Returns:
        限制后的值.
    """
    return max(min_val, min(max_val, value))


def lerp(a: float, b: float, t: float) -> float:
    """线性插值.

    Args:
        a: 起始值.
        b: 结束值.
        t: 插值因子（0=a, 1=b）.

    Returns:
        插值结果.
    """
    return a + (b - a) * t


class FPSCounter:
    """简易FPS计数器.

    用于调试时监控实际帧率.

    用法::
        fps = FPSCounter()
        while running:
            fps.tick()
            if fps.should_report():
                print(f"当前FPS: {fps.fps:.1f}")
    """

    def __init__(self, report_interval: float = 5.0) -> None:
        self.report_interval = report_interval
        self.frame_count = 0
        self.last_report_time = time.time()
        self.fps = 0.0

    def tick(self) -> None:
        """记录一帧."""
        self.frame_count += 1
        now = time.time()
        elapsed = now - self.last_report_time
        if elapsed >= self.report_interval:
            self.fps = self.frame_count / elapsed
            self.frame_count = 0
            self.last_report_time = now

    def should_report(self) -> bool:
        """是否到达报告间隔.

        Returns:
            若距离上次报告已超过 report_interval 秒则返回 True.
        """
        return time.time() - self.last_report_time >= self.report_interval

    def get_fps(self) -> float:
        """获取当前估算FPS.

        Returns:
            最近一个报告周期内的平均FPS.
        """
        return self.fps
