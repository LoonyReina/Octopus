"""语音输入管道 — 录音 + VAD + 腾讯 ASR.

基于 voice_pipeline_spec.md 实现，集成到章鱼助手 HMI：
- arecord 录制原始 PCM
- RMS/dBFS 能量检测 + VAD 状态机
- 腾讯云 SentenceRecognition (TC3 签名)
- 识别结果通过 callback 回传主程序

用法:
    def on_text(text: str):
        print(f"识别到: {text}")

    vp = VoicePipeline(on_text_callback=on_text)
    vp.start()
    # ... 说话 ...
    vp.stop()
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import io
import json
import logging
import math
import os
import re
import struct
import subprocess
import threading
import time
import urllib.request
import wave
from typing import Callable, Optional

logger = logging.getLogger("octopus.voice")

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

CHUNK_DURATION = 0.5          # 每块 0.5 秒
SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2              # S16_LE
CHANNELS = 1
CHUNK_BYTES = int(SAMPLE_RATE * SAMPLE_WIDTH * CHUNK_DURATION)  # 16000

CALIBRATION_CHUNKS = 8        # 校准期 4 秒
THRESHOLD_OFFSET_DB = 6.0     # 阈值 = baseline + 6dB
SILENCE_CHUNKS = 3            # 连续 1.5 秒静音认为句子结束（避免过早截断）
MIN_SPEAKING_CHUNKS = 1       # 至少 0.5 秒语音才送 ASR
MAX_SENTENCE_SECONDS = 15     # 单句最长 15 秒

MIC_DEVICE = "plughw:1,0"     # Jieli 真麦克风

# ---------------------------------------------------------------------------
# 凭据加载
# ---------------------------------------------------------------------------

_sdk_path = "/root/plugin/voice_wake/sdk.md"


def _load_tencent_creds(path: str = _sdk_path) -> tuple[str, str]:
    """从 sdk.md 加载腾讯 ASR 凭据."""
    secret_id = ""
    secret_key = ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        m_id = re.search(r"^SecretId:(.+)$", content, re.MULTILINE)
        m_key = re.search(r"^SecretKey:(.+)$", content, re.MULTILINE)
        if m_id:
            secret_id = m_id.group(1).strip()
        if m_key:
            secret_key = m_key.group(1).strip()
    except Exception as e:
        logger.warning("加载 sdk.md 失败: %s", e)

    if not secret_id or not secret_key:
        raise RuntimeError(f"腾讯 ASR 凭据不完整: {path}")

    masked = f"{secret_id[:3]}***{secret_id[-3:]}" if len(secret_id) > 6 else "***"
    logger.info("[boot] tencent creds loaded id=%s", masked)
    return secret_id, secret_key


# ---------------------------------------------------------------------------
# TC3 签名
# ---------------------------------------------------------------------------


def _tc3_sign(secret_id: str, secret_key: str, body_str: str, region: str = "ap-shanghai") -> tuple[str, int]:
    service = "asr"
    host = "asr.tencentcloudapi.com"
    algorithm = "TC3-HMAC-SHA256"
    timestamp = int(time.time())
    date = time.strftime("%Y-%m-%d", time.gmtime(timestamp))

    http_method = "POST"
    canonical_uri = "/"
    canonical_qs = ""
    ct = "application/json; charset=utf-8"
    canonical_headers = f"content-type:{ct}\nhost:{host}\n"
    signed_headers = "content-type;host"
    hashed_payload = hashlib.sha256(body_str.encode()).hexdigest()
    canonical_request = (
        f"{http_method}\n{canonical_uri}\n{canonical_qs}\n"
        f"{canonical_headers}\n{signed_headers}\n{hashed_payload}"
    )

    credential_scope = f"{date}/{service}/tc3_request"
    hashed_canonical = hashlib.sha256(canonical_request.encode()).hexdigest()
    string_to_sign = f"{algorithm}\n{timestamp}\n{credential_scope}\n{hashed_canonical}"

    def _hmac_sha256(key: bytes, msg: str) -> bytes:
        return hmac.new(key, msg.encode(), hashlib.sha256).digest()

    secret_date = _hmac_sha256(("TC3" + secret_key).encode(), date)
    secret_service = _hmac_sha256(secret_date, service)
    secret_signing = _hmac_sha256(secret_service, "tc3_request")
    signature = hmac.new(secret_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()

    authorization = (
        f"{algorithm} Credential={secret_id}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, Signature={signature}"
    )
    return authorization, timestamp


# ---------------------------------------------------------------------------
# PCM → WAV
# ---------------------------------------------------------------------------


def _pcm_to_wav_bytes(pcm_data: bytes, rate: int = SAMPLE_RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(SAMPLE_WIDTH)
        wf.setframerate(rate)
        wf.writeframes(pcm_data)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# 调用腾讯 ASR
# ---------------------------------------------------------------------------


def _call_tencent_asr(pcm_data: bytes, secret_id: str, secret_key: str) -> Optional[str]:
    wav_bytes = _pcm_to_wav_bytes(pcm_data)
    body = {
        "ProjectId": 0,
        "SubServiceType": 2,
        "EngSerViceType": "16k_zh",
        "SourceType": 1,
        "VoiceFormat": "wav",
        "Data": base64.b64encode(wav_bytes).decode(),
        "DataLen": len(wav_bytes),
    }
    body_str = json.dumps(body, separators=(",", ":"))

    auth, ts = _tc3_sign(secret_id, secret_key, body_str)

    req = urllib.request.Request(
        "https://asr.tencentcloudapi.com/",
        data=body_str.encode(),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": auth,
            "Host": "asr.tencentcloudapi.com",
            "X-TC-Action": "SentenceRecognition",
            "X-TC-Version": "2019-06-14",
            "X-TC-Region": "ap-shanghai",
            "X-TC-Timestamp": str(ts),
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        logger.warning("ASR HTTP 失败: %s", e)
        return None

    response = data.get("Response", {})
    if "Error" in response:
        err = response["Error"]
        logger.warning("ASR 错误: %s - %s", err.get("Code"), err.get("Message"))
        return None

    result = response.get("Result", "").strip()
    if not result:
        logger.debug("[asr] (empty)")
        return None

    return result


# ---------------------------------------------------------------------------
# RMS / dBFS
# ---------------------------------------------------------------------------


def _rms_db(chunk_bytes: bytes) -> float:
    n = len(chunk_bytes) // SAMPLE_WIDTH
    if n == 0:
        return -120.0
    samples = struct.unpack(f"{n}h", chunk_bytes)
    rms = math.sqrt(sum(s * s for s in samples) / n) or 1e-9
    return 20.0 * math.log10(rms / 32767.0)


# ---------------------------------------------------------------------------
# Voice Pipeline 主类
# ---------------------------------------------------------------------------


class VoicePipeline:
    """语音输入管道.

    后台线程运行录音 + VAD，识别到句子后通过 callback 回传文本.
    """

    def __init__(
        self,
        on_text_callback: Callable[[str], None],
        mic_device: str = MIC_DEVICE,
        should_mute_callback: Optional[Callable[[], bool]] = None,
    ) -> None:
        self.on_text_callback = on_text_callback
        self.mic_device = mic_device
        self.should_mute_callback = should_mute_callback

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # 凭据
        self._secret_id: str = ""
        self._secret_key: str = ""

    def start(self) -> None:
        """启动语音监听（后台线程）."""
        if self._running:
            return

        # 加载凭据
        if not self._secret_id:
            try:
                self._secret_id, self._secret_key = _load_tencent_creds()
            except Exception as e:
                logger.error("无法加载 ASR 凭据: %s", e)
                return

        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._record_loop,
            name="VoicePipeline",
            daemon=True,
        )
        self._thread.start()
        logger.info("[voice] 语音监听已启动")

    def stop(self) -> None:
        """停止语音监听."""
        if not self._running:
            return
        self._running = False
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        logger.info("[voice] 语音监听已停止")

    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # 录音循环
    # ------------------------------------------------------------------

    def _record_loop(self) -> None:
        """主录音循环：校准 → VAD → ASR."""
        cmd = [
            "arecord", "-q", "-t", "raw",
            "-f", "S16_LE",
            "-r", str(SAMPLE_RATE),
            "-c", str(CHANNELS),
            "-D", self.mic_device,
            "-",
        ]

        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        except Exception as e:
            logger.error("arecord 启动失败: %s", e)
            self._running = False
            return

        logger.info("[mic] calibrating environment noise...")

        # 校准期
        cal_dbs: list[float] = []
        for i in range(CALIBRATION_CHUNKS):
            chunk = proc.stdout.read(CHUNK_BYTES) if proc.stdout else b""
            if len(chunk) < CHUNK_BYTES:
                logger.warning("[mic] 校准期读数不足")
                break
            db = _rms_db(chunk)
            cal_dbs.append(db)
            logger.info("[mic] cal chunk %d/%d db=%.1f", i + 1, CALIBRATION_CHUNKS, db)

        if len(cal_dbs) < 2:
            logger.error("[mic] 校准失败，无法获取环境噪音")
            proc.terminate()
            proc.wait(timeout=2)
            self._running = False
            return

        baseline_db = sum(cal_dbs) / len(cal_dbs)
        threshold_db = baseline_db + THRESHOLD_OFFSET_DB
        logger.info("[mic] baseline=%.1f dB, threshold=%.1f dB", baseline_db, threshold_db)
        logger.info("[mic] ready. speak 中文 (等待说话...)")

        # VAD 状态机
        state = "silence"
        sentence_buf = bytearray()
        silence_chunks = 0
        speaking_chunks = 0
        sentence_id = 0

        while self._running and not self._stop_event.is_set():
            try:
                chunk = proc.stdout.read(CHUNK_BYTES) if proc.stdout else b""
                if len(chunk) < CHUNK_BYTES:
                    time.sleep(0.05)
                    continue
            except Exception as e:
                logger.error("[mic] 读 chunk 异常: %s", e)
                break

            db = _rms_db(chunk)
            is_speaking = db > threshold_db

            # 扬声器播放时隔绝麦克风
            if self.should_mute_callback and self.should_mute_callback():
                if is_speaking:
                    logger.debug("[mic] muted (TTS playing), discarding %.1f dB", db)
                is_speaking = False

            if state == "silence":
                if is_speaking:
                    state = "speaking"
                    sentence_buf = bytearray(chunk)
                    speaking_chunks = 1
                    silence_chunks = 0
                    logger.info("[speaking] start (energy=%.1f dB > %.1f)", db, threshold_db)
                else:
                    # 滑动更新 baseline
                    baseline_db = 0.95 * baseline_db + 0.05 * db
                    threshold_db = baseline_db + THRESHOLD_OFFSET_DB

            else:  # speaking
                sentence_buf.extend(chunk)
                if is_speaking:
                    speaking_chunks += 1
                    silence_chunks = 0
                else:
                    silence_chunks += 1
                    if silence_chunks >= SILENCE_CHUNKS:
                        # 句子结束
                        trim = silence_chunks * CHUNK_BYTES
                        audio = bytes(sentence_buf[:-trim] if trim < len(sentence_buf) else sentence_buf)
                        if speaking_chunks >= MIN_SPEAKING_CHUNKS and len(audio) >= CHUNK_BYTES:
                            sentence_id += 1
                            logger.info("[speaking] end (silence, dur=%.1fs, %d chunks)",
                                       silence_chunks * CHUNK_DURATION, silence_chunks)
                            threading.Thread(
                                target=self._process_sentence,
                                args=(audio, sentence_id),
                                daemon=True,
                            ).start()
                        state = "silence"
                        sentence_buf = bytearray()
                        speaking_chunks = 0
                        silence_chunks = 0

            # 单句最长截断
            if state == "speaking" and len(sentence_buf) >= SAMPLE_RATE * SAMPLE_WIDTH * MAX_SENTENCE_SECONDS:
                audio = bytes(sentence_buf)
                sentence_id += 1
                logger.info("[speaking] force cut (max %ds)", MAX_SENTENCE_SECONDS)
                threading.Thread(
                    target=self._process_sentence,
                    args=(audio, sentence_id),
                    daemon=True,
                ).start()
                state = "silence"
                sentence_buf = bytearray()
                speaking_chunks = 0
                silence_chunks = 0

        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=1)
        logger.info("[mic] arecord 已终止")

    def _process_sentence(self, audio: bytes, sentence_id: int) -> None:
        """处理单句音频：ASR → callback."""
        logger.info("[句%d] 音频 %.1fKB，送 ASR...", sentence_id, len(audio) / 1024)

        text = _call_tencent_asr(audio, self._secret_id, self._secret_key)
        if text:
            logger.info("[句%d] %s", sentence_id, text)
            try:
                self.on_text_callback(text)
            except Exception as e:
                logger.exception("[voice] callback 异常: %s", e)
        else:
            logger.info("[句%d] ASR 无结果", sentence_id)
