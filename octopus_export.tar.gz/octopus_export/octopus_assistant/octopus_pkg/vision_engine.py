"""视觉引擎 — YOLOv8 ONNX 实时物体识别.

功能:
- 从摄像头捕获帧
- YOLOv8 ONNX 推理
- 维护最近 N 秒的检测结果
- 提供自然语言场景描述

用法:
    from octopus_pkg.vision_engine import VisionEngine
    ve = VisionEngine()
    ve.start()
    # ... 随时询问 ...
    desc = ve.get_scene_description()
    print(desc)
    ve.stop()
"""

from __future__ import annotations

import logging
import threading
import time
from collections import Counter, deque
from typing import Deque, Dict, List, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger("octopus.vision")

# ---------------------------------------------------------------------------
# YOLOv8 ONNX 推理封装
# ---------------------------------------------------------------------------

# Open Images V7 的 600 个类别中，yolov8n-oiv7 实际使用前 600 个（部分为空）
# 这里只列出常见类别用于描述
COMMON_NAMES: Dict[int, str] = {
    0: "人", 1: "男性", 2: "女性", 3: "脸", 4: "手", 5: "手臂", 6: "腿", 7: "脚",
    14: "猫", 15: "狗", 16: "马", 17: "鸟", 18: "鱼", 19: "蝴蝶", 20: "蜜蜂",
    21: "蜘蛛", 22: "蜗牛", 23: "蛇", 24: "青蛙", 25: "乌龟",
    44: "汽车", 45: "卡车", 46: "公交车", 47: "自行车", 48: "摩托车",
    49: "火车", 50: "船", 51: "飞机", 52: "直升机",
    77: "手机", 78: "笔记本电脑", 79: "平板电脑", 80: "显示器", 81: "键盘",
    82: "鼠标", 83: "遥控器", 84: "相机", 85: "耳机",
    116: "杯子", 117: "瓶子", 118: "碗", 119: "盘子", 120: "叉子",
    121: "勺子", 122: "刀",
    180: "椅子", 181: "桌子", 182: "沙发", 183: "床", 184: "柜子",
    185: "书架", 186: "台灯", 187: "窗帘", 188: "门", 189: "窗户",
    263: "眼睛", 264: "眉毛", 265: "鼻子", 266: "嘴唇",
    277: "书", 278: "笔", 279: "纸", 280: "包", 281: "钱包",
    282: "雨伞", 283: "眼镜", 284: "手表", 285: "帽子",
    440: "树", 441: "花", 442: "草", 443: "山", 444: "天空",
    445: "云", 446: "太阳", 447: "月亮", 448: "星星",
    476: "披萨", 477: "汉堡", 478: "三明治", 479: "热狗",
    480: "蛋糕", 481: "甜甜圈", 482: "冰淇淋", 483: "巧克力",
}


def _get_class_name(cls_id: int) -> str:
    return COMMON_NAMES.get(cls_id, f"物体{cls_id}")


class YOLOv8ONNX:
    """YOLOv8 ONNX 推理器."""

    def __init__(
        self,
        model_path: str = "/home/openEuler/yolov8n-oiv7.onnx",
        input_size: Tuple[int, int] = (640, 640),
        conf_threshold: float = 0.35,
        iou_threshold: float = 0.45,
    ) -> None:
        self.model_path = model_path
        self.input_size = input_size
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold

        # 加载模型
        import onnxruntime as ort
        providers = ["CPUExecutionProvider"]
        self.session = ort.InferenceSession(model_path, providers=providers)
        self.input_name = self.session.get_inputs()[0].name

        logger.info("[vision] ONNX 模型已加载: %s", model_path)

    def infer(self, frame: np.ndarray) -> List[Tuple[int, float, int, int, int, int]]:
        """对单帧进行推理.

        Returns:
            [(class_id, conf, x1, y1, x2, y2), ...]
        """
        # 预处理
        orig_h, orig_w = frame.shape[:2]
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, self.input_size)
        img = img.astype(np.float32) / 255.0
        img = np.transpose(img, (2, 0, 1))  # HWC -> CHW
        img = np.expand_dims(img, axis=0)   # BCHW

        # 推理
        outputs = self.session.run(None, {self.input_name: img})
        preds = outputs[0][0]  # (num_dets, 6) 或 (84, 8400) 格式

        # 解析输出
        # yolov8n-oiv7.onnx 输出通常是 (1, 605, 8400)
        # 需要转置为 (8400, 605)
        if preds.shape[0] == 605 and preds.ndim == 2:
            preds = preds.T  # (8400, 605)

        detections = []
        if preds.shape[1] >= 5:
            # YOLOv8 ONNX 输出格式: [x_center, y_center, w, h, cls0, cls1, ...]
            # 注意：没有单独的 objectness 列！
            boxes = preds[:, :4]
            classes = preds[:, 4:]
            # 置信度 = 最高类别分数
            confs = np.max(classes, axis=1)
            cls_ids = np.argmax(classes, axis=1)

            # 只保留置信度足够的
            valid = confs > self.conf_threshold
            boxes = boxes[valid]
            confs = confs[valid]
            cls_ids = cls_ids[valid]

            if len(boxes) == 0:
                return []

            # xywh -> xyxy
            x_c, y_c, w, h = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
            x1 = (x_c - w / 2) / self.input_size[0] * orig_w
            y1 = (y_c - h / 2) / self.input_size[1] * orig_h
            x2 = (x_c + w / 2) / self.input_size[0] * orig_w
            y2 = (y_c + h / 2) / self.input_size[1] * orig_h

            # NMS
            indices = cv2.dnn.NMSBoxes(
                np.column_stack([x1, y1, x2 - x1, y2 - y1]).tolist(),
                confs.tolist(),
                self.conf_threshold,
                self.iou_threshold,
            )
            if len(indices) == 0:
                return []

            if isinstance(indices, tuple):
                indices = indices[0]

            for i in indices.flatten():
                detections.append((
                    int(cls_ids[i]),
                    float(confs[i]),
                    int(x1[i]), int(y1[i]),
                    int(x2[i]), int(y2[i]),
                ))

        return detections


# ---------------------------------------------------------------------------
# 检测结果记录
# ---------------------------------------------------------------------------


class DetectionEntry:
    """单次检测结果记录."""

    def __init__(self, objects: List[Tuple[str, float]]) -> None:
        self.objects = objects          # [(name, conf), ...]
        self.timestamp = time.time()


# ---------------------------------------------------------------------------
# 视觉引擎主类
# ---------------------------------------------------------------------------


class VisionEngine:
    """视觉引擎.

    后台线程持续捕获摄像头画面并进行 YOLO 推理，
    维护最近 10 秒的检测结果，支持自然语言查询.
    """

    def __init__(
        self,
        model_path: str = "/home/openEuler/yolov8n-oiv7.onnx",
        camera_index: int = 0,
        inference_interval: float = 1.0,   # 每秒推理一次
        history_seconds: float = 10.0,      # 保留最近 10 秒结果
    ) -> None:
        self.model_path = model_path
        self.camera_index = camera_index
        self.inference_interval = inference_interval
        self.history_seconds = history_seconds

        self._yolo: Optional[YOLOv8ONNX] = None
        self._cap: Optional[cv2.VideoCapture] = None

        self._history: Deque[DetectionEntry] = deque()
        self._history_lock = threading.Lock()

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self) -> bool:
        """启动视觉引擎."""
        if self._running:
            return True

        # 加载模型
        try:
            self._yolo = YOLOv8ONNX(self.model_path)
        except Exception as e:
            logger.error("[vision] 加载 YOLO 模型失败: %s", e)
            return False

        # 打开摄像头
        self._cap = cv2.VideoCapture(self.camera_index)
        if not self._cap.isOpened():
            logger.error("[vision] 无法打开摄像头 /dev/video%d，尝试 /dev/video1...", self.camera_index)
            self._cap = cv2.VideoCapture(1)
            if not self._cap.isOpened():
                logger.error("[vision] 也无法打开 /dev/video1，请检查摄像头连接和权限")
                return False

        # 设置分辨率（降低以提升速度）
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self._cap.set(cv2.CAP_PROP_FPS, 15)

        # 验证实际分辨率
        actual_w = self._cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        actual_h = self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        logger.info("[vision] 摄像头分辨率: %.0fx%.0f", actual_w, actual_h)

        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._inference_loop,
            name="VisionEngine",
            daemon=True,
        )
        self._thread.start()
        logger.info("[vision] 视觉引擎已启动 (camera=%d)", self.camera_index)
        return True

    def stop(self) -> None:
        """停止视觉引擎."""
        if not self._running:
            return
        self._running = False
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3.0)
        if self._cap:
            self._cap.release()
            self._cap = None
        logger.info("[vision] 视觉引擎已停止")

    def get_scene_description(self) -> str:
        """获取当前场景的自然语言描述.

        基于最近 N 秒的检测结果，生成中文描述.
        """
        with self._history_lock:
            # 清理过期数据
            cutoff = time.time() - self.history_seconds
            while self._history and self._history[0].timestamp < cutoff:
                self._history.popleft()

            if not self._history:
                return "我现在看不到什么东西，画面比较空。"

            # 统计所有检测到的物体（按出现频率加权）
            all_objects: List[str] = []
            has_person = False
            PERSON_NAMES = {"人", "男性", "女性", "脸", "手", "手臂", "腿", "脚", "眼睛", "眉毛", "鼻子", "嘴唇"}
            for entry in self._history:
                for name, conf in entry.objects:
                    if conf > 0.25:
                        all_objects.append(name)
                        if name in PERSON_NAMES:
                            has_person = True

            # 保底策略：只要检测到人相关特征，就确认有人
            if has_person:
                return "我看到你面前有个人。"

            if not all_objects:
                return "画面有点模糊，看不太清楚有什么。"

            counter = Counter(all_objects)
            total = len(self._history)

            # 取出现频率最高的几个
            top = counter.most_common(5)

            parts = []
            for name, count in top:
                ratio = count / total
                if ratio > 0.7:
                    parts.append(f"{name}")
                elif ratio > 0.3:
                    parts.append(f"一些{name}")
                else:
                    parts.append(f"偶尔看到{name}")

            if len(parts) == 1:
                return f"我看到画面里有{parts[0]}。"
            elif len(parts) == 2:
                return f"我看到画面里有{parts[0]}和{parts[1]}。"
            else:
                desc = "、".join(parts[:-1]) + f"和{parts[-1]}"
                return f"我看到画面里有{desc}。"

    def is_running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------
    # 推理循环
    # ------------------------------------------------------------------

    def _inference_loop(self) -> None:
        """后台推理循环."""
        while self._running and not self._stop_event.is_set():
            if self._cap is None or self._yolo is None:
                time.sleep(0.5)
                continue

            ret, frame = self._cap.read()
            if not ret or frame is None:
                time.sleep(0.1)
                continue

            try:
                dets = self._yolo.infer(frame)
                objects = [
                    (_get_class_name(cls_id), conf)
                    for cls_id, conf, *_ in dets
                ]

                with self._history_lock:
                    self._history.append(DetectionEntry(objects))
                    # 清理过期
                    cutoff = time.time() - self.history_seconds
                    while self._history and self._history[0].timestamp < cutoff:
                        self._history.popleft()

                if objects:
                    names = [n for n, _ in objects]
                    logger.debug("[vision] 检测到: %s", ", ".join(names[:5]))

            except Exception as e:
                logger.warning("[vision] 推理异常: %s", e)

            # 按间隔休眠
            self._stop_event.wait(self.inference_interval)
