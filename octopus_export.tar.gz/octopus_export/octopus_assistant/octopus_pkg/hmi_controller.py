"""HMI 控制器 — 通过串口指令控制 TJC 串口屏.

烧录 HMI 工程后，本模块替代原来的实时矢量渲染，改为发送简洁的串口指令：
- 切换表情: p_face.pic=N
- 更新文字: t_status.txt="..."
- 接收触摸: 0x65 组件事件

用法:
    from octopus_pkg.hmi_controller import HMIController

    ctrl = HMIController(port="/dev/ttyAMA2", baudrate=19200)
    ctrl.connect()
    ctrl.set_emotion("happy")
    ctrl.set_status_text("会话 abc123")
"""

from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("octopus.hmi")

EOF = b"\xff\xff\xff"

# 默认眨眼间隔（可被外部配置覆盖）
DEFAULT_BLINK_INTERVAL_MIN = 2.0
DEFAULT_BLINK_INTERVAL_MAX = 4.0
DEFAULT_BLINK_DURATION = 0.5


# ============================================================================
# 表情枚举（与 pic ID 映射保持一致）
# ============================================================================

class OctopusEmotion(Enum):
    """章鱼表情 — 对应 HMI 工程中 p_face 控件的 pic 属性."""

    HAPPY = "happy"           # pic=1
    WINK = "wink"             # pic=2
    SURPRISED = "surprised"   # pic=3
    SHY = "shy"               # pic=4
    SAD = "sad"               # pic=5
    ANGRY = "angry"           # pic=6
    DAZED = "dazed"           # pic=7
    WAVING = "waving"         # pic=8
    CARING = "caring"         # pic=9
    TIRED = "tired"           # pic=10


EMOTION_PIC_MAP: Dict[str, int] = {
    "happy": 1,
    "wink": 2,
    "surprised": 3,
    "shy": 4,
    "sad": 5,
    "angry": 6,
    "dazed": 7,
    "waving": 8,
    "caring": 9,
    "tired": 10,
}


# ============================================================================
# 触摸事件
# ============================================================================

@dataclass
class HMIEevent:
    """HMI 触摸事件."""

    event_type: str  # "press" | "release" | "component"
    page_id: int = 0
    component_id: int = 0
    x: Optional[int] = None
    y: Optional[int] = None
    raw_data: bytes = field(default_factory=bytes)


# ============================================================================
# 眨眼动画管理器
# ============================================================================

class BlinkManager:
    """自动眨眼动画管理器.

    后台线程定时触发眨眼：
    - 随机间隔内睡眠
    - 切换到 wink 表情
    - 短暂停留后恢复基础表情
    - 仅在表情显示模式下工作（不在休眠/完整章鱼模式）
    """

    def __init__(
        self,
        hmi: "HMIController",
        interval_min: float = DEFAULT_BLINK_INTERVAL_MIN,
        interval_max: float = DEFAULT_BLINK_INTERVAL_MAX,
        duration: float = DEFAULT_BLINK_DURATION,
    ) -> None:
        self.hmi = hmi
        self.interval_min = interval_min
        self.interval_max = interval_max
        self.duration = duration

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._is_blinking = False
        self._enabled = True

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def start(self) -> None:
        """启动眨眼线程."""
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name="BlinkManager",
            daemon=True,
        )
        self._thread.start()
        logger.info("眨眼动画已启动 (间隔 %.1f~%.1f 秒)",
                    self.interval_min, self.interval_max)

    def stop(self) -> None:
        """停止眨眼线程."""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        logger.info("眨眼动画已停止")

    def enable(self) -> None:
        """允许眨眼（进入表情显示模式时调用）."""
        self._enabled = True
        logger.debug("眨眼已启用")

    def disable(self) -> None:
        """禁止眨眼（进入休眠模式时调用）."""
        self._enabled = False
        logger.debug("眨眼已禁用")

    # ------------------------------------------------------------------
    # 核心循环
    # ------------------------------------------------------------------

    def _loop(self) -> None:
        """后台循环：随机间隔 → 眨眼 → 恢复."""
        while self._running:
            try:
                # 随机睡眠间隔
                interval = random.uniform(self.interval_min, self.interval_max)
                time.sleep(interval)

                if not self._running:
                    break

                # 仅在启用状态下眨眼
                if not self._enabled:
                    continue

                self._do_blink()

            except Exception as e:
                logger.error("眨眼循环异常: %s", e)
                time.sleep(1.0)

    def _do_blink(self) -> None:
        """执行一次眨眼动作."""
        with self._lock:
            if self._is_blinking:
                return
            self._is_blinking = True

        try:
            # 获取当前基础表情 pic ID
            base_pic = self.hmi.get_current_emotion_pic()

            # 切换到眨眼
            logger.debug("眨眼: wink (pic=2)")
            self.hmi.send_cmd("p_face.pic=2")

            # 保持眨眼状态
            time.sleep(self.duration)

            # 恢复基础表情
            logger.debug("眨眼恢复: pic=%d", base_pic)
            self.hmi.send_cmd(f"p_face.pic={base_pic}")

        except Exception as e:
            logger.error("眨眼执行异常: %s", e)
        finally:
            with self._lock:
                self._is_blinking = False


# ============================================================================
# HMI 控制器
# ============================================================================

class HMIController:
    """TJC HMI 串口屏控制器.

    通过串口发送 ASCII 指令控制已烧录的 HMI 工程。
    """

    def __init__(
        self,
        port: str = "/dev/ttyAMA2",
        baudrate: int = 19200,
        timeout: float = 1.0,
    ) -> None:
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout

        self._serial: Any = None
        self._connected = False
        self._lock = threading.Lock()
        self._read_thread: Optional[threading.Thread] = None
        self._running = False

        self._touch_callbacks: List[Callable[[HMIEevent], None]] = []
        self._status_callbacks: List[Callable[[str], None]] = []

        # 当前显示的表情 pic ID（用于眨眼恢复）
        self._current_emotion_pic = EMOTION_PIC_MAP["caring"]

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        """连接串口."""
        try:
            import serial
        except ImportError:
            logger.error("需要安装 pyserial: pip3 install pyserial")
            return False

        try:
            self._serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=self.timeout,
            )
            self._connected = True
            self._running = True
            logger.info("HMI 串口已连接: %s @ %d", self.port, self.baudrate)

            self._read_thread = threading.Thread(
                target=self._read_loop,
                name="HMI-Reader",
                daemon=True,
            )
            self._read_thread.start()
            return True
        except Exception as e:
            logger.error("HMI 串口连接失败: %s", e)
            return False

    def disconnect(self) -> None:
        """断开串口."""
        self._running = False
        self._connected = False

        if self._read_thread and self._read_thread.is_alive():
            self._read_thread.join(timeout=1.0)

        if self._serial:
            try:
                self._serial.close()
            except Exception:
                pass
            self._serial = None

        logger.info("HMI 串口已断开")

    def is_connected(self) -> bool:
        return self._connected

    # ------------------------------------------------------------------
    # 核心指令发送
    # ------------------------------------------------------------------

    def send_cmd(self, cmd: str) -> bool:
        """发送单条指令（自动追加 EOF）."""
        if not self._connected or not self._serial:
            logger.debug("串口未连接，指令丢弃: %s", cmd)
            return False

        try:
            data = cmd.encode("utf-8", errors="ignore") + EOF
            with self._lock:
                self._serial.write(data)
            logger.debug("HMI 发送: %s", cmd)
            return True
        except Exception as e:
            logger.error("HMI 发送失败: %s | %s", cmd, e)
            return False

    def send_batch(self, cmds: List[str]) -> bool:
        """批量发送指令（合并为一次串口写入）."""
        if not self._connected or not self._serial:
            logger.debug("串口未连接，%d 条指令丢弃", len(cmds))
            return False

        if not cmds:
            return True

        try:
            chunks: List[bytes] = []
            for cmd in cmds:
                chunks.append(cmd.encode("utf-8", errors="ignore"))
                chunks.append(EOF)
            data = b"".join(chunks)
            with self._lock:
                self._serial.write(data)
            logger.debug("HMI 批量发送 %d 条指令", len(cmds))
            return True
        except Exception as e:
            logger.error("HMI 批量发送失败: %s", e)
            return False

    # ------------------------------------------------------------------
    # 高层封装：表情/文字/页面
    # ------------------------------------------------------------------

    def set_emotion(self, emotion: OctopusEmotion) -> bool:
        """切换章鱼表情（自动隐藏完整章鱼，显示表情）."""
        pic_id = EMOTION_PIC_MAP.get(emotion.value, 9)
        cmds = [
            "vis p_sleep,0",      # 隐藏完整章鱼
            f"p_face.pic={pic_id}",
            "vis p_face,1",       # 确保表情可见
        ]
        ok = self.send_batch(cmds)
        if ok:
            self._current_emotion_pic = pic_id
            logger.info("HMI 表情切换: %s (pic=%d)", emotion.value, pic_id)
        return ok

    def get_current_emotion_pic(self) -> int:
        """获取当前基础表情 pic ID（用于眨眼恢复）."""
        return self._current_emotion_pic

    def set_emotion_by_name(self, name: str) -> bool:
        """通过字符串名称切换表情."""
        try:
            emotion = OctopusEmotion(name)
            return self.set_emotion(emotion)
        except ValueError:
            logger.warning("未知表情: %s", name)
            return False

    def set_status_text(self, text: str) -> bool:
        """更新状态文字."""
        text = text[:40].replace('"', '\\"')
        return self.send_cmd(f't_status.txt="{text}"')

    def set_message_text(self, text: str) -> bool:
        """更新消息文字."""
        text = text[:60].replace('"', '\\"')
        return self.send_cmd(f't_message.txt="{text}"')

    def set_conn_status(self, status: str, color: Optional[int] = None) -> bool:
        """更新连接状态文字（可选颜色）."""
        status = status[:10].replace('"', '\\"')
        cmds = [f't_conn.txt="{status}"']
        if color is not None:
            cmds.append(f"t_conn.pco={color}")
        return self.send_batch(cmds)

    def goto_page(self, page_name: str) -> bool:
        """跳转页面."""
        return self.send_cmd(f"page {page_name}")

    def show_face(self, visible: bool = True) -> bool:
        """显示/隐藏表情."""
        return self.send_cmd(f"vis p_face,{1 if visible else 0}")

    def show_sleep(self) -> bool:
        """显示完整章鱼（休眠/启动状态），隐藏表情."""
        cmds = [
            "vis p_sleep,1",    # 显示完整章鱼
            "vis p_face,0",     # 隐藏表情
        ]
        ok = self.send_batch(cmds)
        if ok:
            logger.info("HMI 进入休眠状态: 显示完整章鱼")
        return ok

    def hide_sleep(self) -> bool:
        """隐藏完整章鱼."""
        return self.send_cmd("vis p_sleep,0")

    def init_screen(self) -> bool:
        """初始化屏幕（开机后调用一次）."""
        cmds = [
            "bkcmd=0",          # 关闭指令执行结果返回，减少串口流量
            "sendxy=0",         # 关闭坐标触摸上报（使用组件事件）
            "page main",        # 跳转到主页面
            "vis p_sleep,1",    # 显示完整章鱼
            "vis p_face,0",     # 隐藏表情
        ]
        return self.send_batch(cmds)

    # ------------------------------------------------------------------
    # 触摸回调注册
    # ------------------------------------------------------------------

    def register_touch_callback(self, callback: Callable[[HMIEevent], None]) -> None:
        self._touch_callbacks.append(callback)

    def unregister_touch_callback(self, callback: Callable[[HMIEevent], None]) -> None:
        if callback in self._touch_callbacks:
            self._touch_callbacks.remove(callback)

    # ------------------------------------------------------------------
    # 串口数据读取与解析
    # ------------------------------------------------------------------

    def _read_loop(self) -> None:
        """后台读取线程：解析串口屏返回的触摸事件."""
        buffer = bytearray()

        while self._running:
            try:
                if not self._serial or not self._serial.is_open:
                    time.sleep(0.1)
                    continue

                chunk = self._serial.read(64)
                if not chunk:
                    continue

                buffer.extend(chunk)
                self._parse_buffer(buffer)
            except Exception as e:
                logger.error("HMI 读取异常: %s", e)
                time.sleep(0.5)

    def _parse_buffer(self, buffer: bytearray) -> None:
        """解析缓冲区中的完整帧."""
        while True:
            eof_idx = buffer.find(EOF)
            if eof_idx < 0:
                break

            frame = bytes(buffer[:eof_idx])
            del buffer[:eof_idx + 3]

            if not frame:
                continue

            event = self._parse_frame(frame)
            if event:
                for cb in self._touch_callbacks:
                    try:
                        cb(event)
                    except Exception as e:
                        logger.error("触摸回调异常: %s", e)

    def _parse_frame(self, frame: bytes) -> Optional[HMIEevent]:
        """解析单帧数据."""
        if len(frame) < 1:
            return None

        event_code = frame[0]

        # 0x65 组件触控事件
        if event_code == 0x65 and len(frame) >= 4:
            page_id = frame[1]
            component_id = frame[2]
            event_type = "press" if frame[3] == 0x01 else "release"
            return HMIEevent(
                event_type=event_type,
                page_id=page_id,
                component_id=component_id,
                raw_data=frame,
            )

        # 0x67 坐标触控事件（若开启了 sendxy=1）
        if event_code == 0x67 and len(frame) >= 6:
            x = (frame[1] << 8) | frame[2]
            y = (frame[3] << 8) | frame[4]
            raw_type = frame[5]
            event_type = "press" if raw_type == 0x01 else "release"
            return HMIEevent(
                event_type=event_type,
                x=x,
                y=y,
                raw_data=frame,
            )

        # 0x68 睡眠模式触摸
        if event_code == 0x68 and len(frame) >= 6:
            x = (frame[1] << 8) | frame[2]
            y = (frame[3] << 8) | frame[4]
            event_type = "press" if frame[5] == 0x01 else "release"
            return HMIEevent(
                event_type=event_type,
                x=x,
                y=y,
                raw_data=frame,
            )

        # 其他通知码（忽略）
        logger.debug("忽略 HMI 返回帧: %s", frame.hex())
        return None


# ============================================================================
# 便捷工厂函数
# ============================================================================

def create_hmi_controller(port: str = "/dev/ttyAMA2", baudrate: int = 19200) -> HMIController:
    """创建 HMI 控制器实例."""
    return HMIController(port=port, baudrate=baudrate)
