"""陶晶驰(TJC)串口屏通信核心模块.

提供 TJCScreen 单例类，负责串口连接管理、指令发送、响应读取及触控事件监听。
协议：ASCII 指令 + 结束符 0xFF 0xFF 0xFF (\xff\xff\xff)。
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, List, Optional

# 延迟导入 serial：仅在需要时才尝试导入
# 这样在没有 pyserial 的环境下也可以导入数据类和协议常量
try:
    import serial as _serial_mod
    _HAS_SERIAL = True
except ImportError:
    # 尝试加载本地 stub
    try:
        import serial_stub as _serial_mod
        _HAS_SERIAL = True
    except ImportError:
        _serial_mod = None  # type: ignore
        _HAS_SERIAL = False

# 便捷别名（供其他模块使用）
serial = _serial_mod

# 模块级日志器
logger = logging.getLogger(__name__)

# 协议常量
TJC_EOF = b"\xff\xff\xff"
TJC_EOF_LEN = len(TJC_EOF)

# 触控事件类型
TOUCH_EVENT_PRESS = "press"
TOUCH_EVENT_RELEASE = "release"


def rgb_to_565(r: int, g: int, b: int) -> int:
    """将 RGB888 颜色值转换为 RGB565 格式。

    陶晶驰串口屏使用 16 位 RGB565 颜色格式。
    转换公式:
        R5 = (R * 31 / 255) << 11
        G6 = (G * 63 / 255) << 5
        B5 = (B * 31 / 255)

    Args:
        r: 红色分量，范围 0-255。
        g: 绿色分量，范围 0-255。
        b: 蓝色分量，范围 0-255。

    Returns:
        16 位 RGB565 颜色值，范围 0x0000-0xFFFF。
    """
    r = max(0, min(255, r))
    g = max(0, min(255, g))
    b = max(0, min(255, b))
    r5 = (r * 31 + 127) // 255
    g6 = (g * 63 + 127) // 255
    b5 = (b * 31 + 127) // 255
    return (r5 << 11) | (g6 << 5) | b5


@dataclass
class TouchEvent:
    """触控事件数据类。

    封装从陶晶驰串口屏解析出的触控事件信息。

    Attributes:
        page_id: 事件发生的页面 ID。
        component_id: 触发事件的组件 ID。
        event_type: 事件类型，"press" (按下) 或 "release" (松开)。
        x: 触控 X 坐标 (0x67 坐标事件时有效)，否则为 None。
        y: 触控 Y 坐标 (0x67 坐标事件时有效)，否则为 None。
        raw_data: 从串口读取的原始事件字节数据。
    """
    page_id: int
    component_id: int
    event_type: str
    x: Optional[int] = None
    y: Optional[int] = None
    raw_data: bytes = b""


class TJCScreen:
    """陶晶驰串口屏通信核心类（线程安全单例模式）。

    职责:
        - 管理串口连接 (/dev/ttyAMA2, 波特率 19200)
        - 发送绘图/控制指令，自动追加 0xFF 0xFF 0xFF 结束符
        - 读取串口屏返回的响应数据
        - 启动守护线程监听触控事件，通过回调分发 TouchEvent

    单例实现:
        使用 ``_instance`` 类变量配合 ``_lock`` 线程锁，
        确保全局只有一个 TJCScreen 实例。

    线程安全:
        所有串口读写操作均受 ``_cmd_lock`` 保护，保证指令串行化。

    Attributes:
        _instance: 类级单例实例引用。
        _lock: 类级锁，用于单例创建同步。
    """

    _instance: Optional["TJCScreen"] = None
    _lock = threading.Lock()

    def __new__(cls, *args: Any, **kwargs: Any) -> "TJCScreen":
        """单例构造器，确保全局只有一个实例。"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(
        self,
        port: str = "/dev/ttyAMA2",
        baudrate: int = 19200,
        width: int = 480,
        height: int = 272,
        timeout: float = 1.0,
    ) -> None:
        """初始化串口屏通信实例。

        注意：单例模式下，仅第一次调用会真正执行初始化。

        Args:
            port: 串口设备路径，默认 ``/dev/ttyAMA2``。
            baudrate: 通信波特率，默认 ``19200``。
            width: 屏幕宽度（像素），默认 ``480``。
            height: 屏幕高度（像素），默认 ``272``。
            timeout: 串口读超时时间（秒），默认 ``1.0``。
        """
        # 避免重复初始化（单例）
        if hasattr(self, "_initialized"):
            return
        self._initialized = True

        self._port = port
        self._baudrate = baudrate
        self._width = width
        self._height = height
        self._timeout = timeout

        # 串口对象及状态
        self._serial: Any = None
        self._connected = False

        # 指令级锁：保证串口操作串行化
        self._cmd_lock = threading.Lock()

        # 触控监听线程
        self._touch_thread: Optional[threading.Thread] = None
        self._touch_stop_event = threading.Event()
        self._touch_callbacks: List[Callable[[TouchEvent], None]] = []
        self._touch_callbacks_lock = threading.Lock()

        logger.info(
            "TJCScreen 实例已创建: port=%s, baudrate=%d, size=%dx%d",
            port,
            baudrate,
            width,
            height,
        )

    # ------------------------------------------------------------------
    # 串口连接管理
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        """建立串口连接，带 3 次重试机制。

        依次尝试打开串口，失败时等待 2 秒后重试，最多重试 3 次。

        Returns:
            连接成功返回 ``True``，否则返回 ``False``。
        """
        if not _HAS_SERIAL:
            logger.error("pyserial 未安装，无法连接串口。请执行: pip3 install pyserial")
            return False

        if self._connected and self._serial is not None and self._serial.is_open:
            logger.info("串口已连接，无需重复连接")
            return True

        max_retries = 3
        retry_delay = 2.0

        for attempt in range(1, max_retries + 1):
            try:
                logger.info(
                    "正在连接串口 %s (波特率 %d) — 第 %d/%d 次尝试",
                    self._port,
                    self._baudrate,
                    attempt,
                    max_retries,
                )
                self._serial = serial.Serial(
                    port=self._port,
                    baudrate=self._baudrate,
                    timeout=self._timeout,
                    bytesize=serial.EIGHTBITS,
                    parity=serial.PARITY_NONE,
                    stopbits=serial.STOPBITS_ONE,
                )
                time.sleep(0.1)  # 等待串口稳定
                self._connected = True
                logger.info("串口连接成功: %s", self._port)
                return True
            except serial.SerialException as exc:
                logger.warning(
                    "串口连接失败 (尝试 %d/%d): %s", attempt, max_retries, exc
                )
                if attempt < max_retries:
                    time.sleep(retry_delay)
                else:
                    logger.error(
                        "串口连接最终失败，已达到最大重试次数 %d", max_retries
                    )
        return False

    def disconnect(self) -> None:
        """断开串口连接并释放资源。

        注意：此方法不自动停止触控监听线程，调用方应在断开前
        显式调用 ``stop_touch_listener()`` 以确保线程干净退出。
        """
        with self._cmd_lock:
            if self._serial is not None and self._serial.is_open:
                try:
                    self._serial.close()
                    logger.info("串口已断开: %s", self._port)
                except serial.SerialException as exc:
                    logger.error("关闭串口时发生错误: %s", exc)
            self._serial = None
            self._connected = False

    def is_connected(self) -> bool:
        """检查当前串口是否处于连接状态。

        Returns:
            已连接返回 ``True``，否则返回 ``False``。
        """
        return (
            self._connected
            and self._serial is not None
            and self._serial.is_open
        )

    # ------------------------------------------------------------------
    # 核心指令发送
    # ------------------------------------------------------------------

    def send_cmd(self, cmd: str) -> bool:
        """发送 ASCII 指令，自动追加结束符 ``\\xff\\xff\\xff``。

        指令文本使用 GB2312 编码发送（陶晶驰协议要求）。

        Args:
            cmd: 要发送的指令字符串（不含结束符）。例如 ``"cls 0x0000"``。

        Returns:
            发送成功返回 ``True``，失败返回 ``False``。
        """
        if not self.is_connected():
            logger.error("send_cmd 失败: 串口未连接")
            return False

        try:
            encoded = cmd.encode("gb2312", errors="ignore")
        except LookupError:
            encoded = cmd.encode("latin1", errors="ignore")

        data = encoded + TJC_EOF

        with self._cmd_lock:
            try:
                self._serial.write(data)
                self._serial.flush()
                logger.debug("发送指令: %s", cmd)
                return True
            except serial.SerialException as exc:
                logger.error("指令发送失败: %s (cmd=%s)", exc, cmd)
                self._connected = False
                return False
            except serial.SerialTimeoutException:
                logger.error("指令发送超时 (cmd=%s)", cmd)
                return False

    def send_raw(self, data: bytes) -> bool:
        """发送原始字节数据到串口屏。

        不自动追加结束符，适用于需要精确控制字节流的场景。

        Args:
            data: 要发送的原始字节数据。

        Returns:
            发送成功返回 ``True``，失败返回 ``False``。
        """
        if not self.is_connected():
            logger.error("send_raw 失败: 串口未连接")
            return False

        with self._cmd_lock:
            try:
                self._serial.write(data)
                self._serial.flush()
                logger.debug("发送原始数据: %d bytes", len(data))
                return True
            except serial.SerialException as exc:
                logger.error("原始数据发送失败: %s", exc)
                self._connected = False
                return False
            except serial.SerialTimeoutException:
                logger.error("原始数据发送超时")
                return False

    def send_batch(self, cmds: List[str]) -> bool:
        """批量发送多条指令，合并为单次串口写入以优化性能。

        将多条指令及其结束符合并为一个字节流发送，减少串口开销。
        单次批量发送不受性能保护上限影响，但调用方应自行控制指令数量。

        Args:
            cmds: 指令字符串列表，每条指令不含结束符。

        Returns:
            全部发送成功返回 ``True``，任一失败返回 ``False``。
        """
        if not self.is_connected():
            logger.error("send_batch 失败: 串口未连接")
            return False

        if not cmds:
            return True

        # 合并所有指令
        chunks: List[bytes] = []
        for cmd in cmds:
            try:
                encoded = cmd.encode("gb2312", errors="ignore")
            except LookupError:
                encoded = cmd.encode("latin1", errors="ignore")
            chunks.append(encoded)
            chunks.append(TJC_EOF)

        batch_data = b"".join(chunks)

        with self._cmd_lock:
            try:
                self._serial.write(batch_data)
                self._serial.flush()
                logger.debug("批量发送 %d 条指令, 共 %d bytes", len(cmds), len(batch_data))
                return True
            except serial.SerialException as exc:
                logger.error("批量发送失败: %s", exc)
                self._connected = False
                return False
            except serial.SerialTimeoutException:
                logger.error("批量发送超时")
                return False

    # ------------------------------------------------------------------
    # 响应读取
    # ------------------------------------------------------------------

    def read_response(self, timeout: float = 0.5) -> Optional[bytes]:
        """读取串口屏返回的响应数据。

        使用非阻塞方式读取当前串口缓冲区中所有可用数据。
        若串口屏无数据返回，在超时后返回已读取内容。

        Args:
            timeout: 读取超时时间（秒），默认 ``0.5``。

        Returns:
            读取到的原始字节数据；无数据或连接断开时返回 ``None``。
        """
        if not self.is_connected():
            logger.error("read_response 失败: 串口未连接")
            return None

        with self._cmd_lock:
            try:
                original_timeout = self._serial.timeout
                self._serial.timeout = timeout
                data = self._serial.read_all()
                self._serial.timeout = original_timeout
                if data:
                    logger.debug("读取响应: %d bytes", len(data))
                    return data
                return None
            except serial.SerialException as exc:
                logger.error("读取响应失败: %s", exc)
                self._connected = False
                return None

    # ------------------------------------------------------------------
    # 触控事件监听
    # ------------------------------------------------------------------

    def register_touch_callback(
        self, callback: Callable[[TouchEvent], None]
    ) -> None:
        """注册触控事件回调函数。

        当串口屏产生触控事件时，所有已注册的回调将被依次调用。
        回调函数应接收一个 ``TouchEvent`` 参数，不返回值。

        Args:
            callback: 触控事件处理函数，签名 ``callback(event: TouchEvent) -> None``。
        """
        with self._touch_callbacks_lock:
            if callback not in self._touch_callbacks:
                self._touch_callbacks.append(callback)
                logger.info("触控回调已注册，当前共 %d 个", len(self._touch_callbacks))
            else:
                logger.warning("该回调函数已被注册，忽略重复注册")

    def start_touch_listener(self) -> None:
        """启动触控事件监听守护线程。

        开启一个后台线程持续读取串口数据，解析陶晶驰触控协议，
        并通过已注册的回调分发 ``TouchEvent``。
        线程为守护线程（daemon），主程序退出时自动终止。

        Raises:
            RuntimeError: 串口未连接时调用此方法。
        """
        if not self.is_connected():
            raise RuntimeError("无法启动触控监听：串口未连接")

        if self._touch_thread is not None and self._touch_thread.is_alive():
            logger.info("触控监听线程已在运行")
            return

        self._touch_stop_event.clear()
        self._touch_thread = threading.Thread(
            target=self._touch_listen_loop,
            name="TouchListener",
            daemon=True,
        )
        self._touch_thread.start()
        logger.info("触控监听线程已启动")

    def stop_touch_listener(self) -> None:
        """停止触控事件监听线程。

        通过设置停止事件信号，通知监听线程在解析完当前帧后退出。
        阻塞等待线程结束，最长等待 2 秒。
        """
        if self._touch_thread is None or not self._touch_thread.is_alive():
            logger.info("触控监听线程未运行")
            return

        self._touch_stop_event.set()
        self._touch_thread.join(timeout=2.0)
        if self._touch_thread.is_alive():
            logger.warning("触控监听线程未能及时停止")
        else:
            logger.info("触控监听线程已停止")
        self._touch_thread = None

    def _touch_listen_loop(self) -> None:
        """触控事件监听循环（内部方法，在线程中运行）。

        持续读取串口数据，解析以下陶晶驰协议事件：
            - ``0x65`` 组件触控事件
            - ``0x67`` 坐标触控事件
            - ``0x88`` 系统启动完成事件
            - ``0x86`` 睡眠/唤醒事件
        解析到有效事件后，通过回调分发给上层处理器。
        遇到解析异常时记录原始 hex 数据并丢弃该帧，继续监听。

        注意：串口读取操作不在 ``_cmd_lock`` 保护下进行，以避免
        主循环发送大量绘图指令时阻塞触控事件读取。
        """
        logger.info("触控监听循环已启动")
        buffer = bytearray()
        no_data_count = 0

        while not self._touch_stop_event.is_set():
            if not self.is_connected():
                time.sleep(0.1)
                continue

            try:
                # 读取可用数据（读取操作不加锁，避免阻塞）
                chunk = self._serial.read_all()
                if chunk:
                    buffer.extend(chunk)
                    no_data_count = 0
                else:
                    no_data_count += 1
                    # 长时间无数据时增加休眠，降低 CPU
                    if no_data_count > 10:
                        time.sleep(0.02)
                    else:
                        time.sleep(0.005)

                # 尝试解析缓冲区中的完整事件帧
                while True:
                    parsed = self._parse_touch_buffer(buffer)
                    if parsed:
                        event, consumed = parsed
                        del buffer[:consumed]
                        if event is not None:
                            self._dispatch_touch_event(event)
                    else:
                        break

                # 缓冲区过大时截断，防止内存泄漏
                if len(buffer) > 4096:
                    logger.warning(
                        "触控数据缓冲区过大 (%d bytes)，丢弃未解析数据", len(buffer)
                    )
                    buffer.clear()

            except Exception as exc:
                logger.error("触控监听循环异常: %s", exc)
                time.sleep(0.1)

        logger.info("触控监听循环已退出")

    def _parse_touch_buffer(
        self, buffer: bytearray
    ) -> Optional[tuple]:
        """解析触控缓冲区中的完整事件帧。

        查找以 ``0xFF 0xFF 0xFF`` 结尾的完整事件包。

        Args:
            buffer: 当前累积的串口数据缓冲区。

        Returns:
            若解析到完整事件，返回 ``(TouchEvent, 消耗字节数)``；
            若未找到完整帧，返回 ``None``；
            若解析到非触控事件（如 ``0x88``），返回 ``(None, 消耗字节数)``。
        """
        if len(buffer) < 4:
            return None

        # 查找结束符位置
        eof_idx = -1
        for i in range(len(buffer) - 2):
            if buffer[i : i + 3] == TJC_EOF:
                eof_idx = i + 3
                break

        if eof_idx == -1:
            return None

        frame = bytes(buffer[:eof_idx])

        # 解析事件类型
        if len(frame) < 1:
            return None, eof_idx

        event_code = frame[0]

        # 0x65 组件触控事件: 0x65 <page_id> <component_id> <event_type> 0xFF 0xFF 0xFF
        # 厂商 HMI 的热点会产生这类事件，直接丢弃，避免干扰我们的坐标触控
        if event_code == 0x65 and len(frame) >= 5:
            page_id = frame[1]
            component_id = frame[2]
            logger.debug("忽略厂商组件触控事件: page=%d comp=%d", page_id, component_id)
            return None, eof_idx

        # 0x67 坐标触控事件（紧凑格式）:
        # 0x67 <x_h> <x_l> <y_h> <y_l> <event_type> 0xFF 0xFF 0xFF
        # 总长度 9 字节（含 EOF）
        if event_code == 0x67 and len(frame) >= 9:
            # 紧凑格式：无 page_id/state，直接 x,y + event
            x = (frame[1] << 8) | frame[2]
            y = (frame[3] << 8) | frame[4]
            raw_type = frame[5]
            event_type = TOUCH_EVENT_PRESS if raw_type == 0x01 else TOUCH_EVENT_RELEASE
            event = TouchEvent(
                page_id=0,
                component_id=0,
                event_type=event_type,
                x=x,
                y=y,
                raw_data=frame,
            )
            return event, eof_idx

        # 0x67 坐标触控事件（扩展格式，部分固件）:
        # 0x67 <page_id> <state> <x_h> <x_l> <y_h> <y_l> <event_type> 0x00 0xFF 0xFF 0xFF
        if event_code == 0x67 and len(frame) >= 12:
            page_id = frame[1]
            state = frame[2]
            x = (frame[3] << 8) | frame[4]
            y = (frame[5] << 8) | frame[6]
            raw_type = frame[7]
            event_type = TOUCH_EVENT_PRESS if raw_type == 0x01 else TOUCH_EVENT_RELEASE
            event = TouchEvent(
                page_id=page_id,
                component_id=state,
                event_type=event_type,
                x=x,
                y=y,
                raw_data=frame,
            )
            return event, eof_idx

        # 0x88 启动完成事件
        if event_code == 0x88:
            logger.info("收到串口屏启动完成信号 (0x88)")
            return None, eof_idx

        # 0x68 页面/状态上报事件（部分固件周期性发送）
        if event_code == 0x68:
            logger.debug("忽略状态上报事件 0x68")
            return None, eof_idx

        # 0x86 睡眠/唤醒事件: 0x86 <sleep_state> 0xFF 0xFF 0xFF
        if event_code == 0x86 and len(frame) >= 2:
            sleep_state = frame[1]
            logger.info("收到睡眠/唤醒事件: sleep_state=%d", sleep_state)
            return None, eof_idx

        # 未知事件类型，记录原始数据并丢弃
        logger.warning(
            "未知触控事件类型 0x%02X, 原始数据: %s", event_code, frame.hex()
        )
        return None, eof_idx

    def _dispatch_touch_event(self, event: TouchEvent) -> None:
        """分发触控事件到所有已注册的回调。

        回调调用异常会被捕获并记录，不影响其他回调执行。

        Args:
            event: 要分发的触控事件对象。
        """
        with self._touch_callbacks_lock:
            callbacks = list(self._touch_callbacks)

        if not callbacks:
            logger.debug(
                "收到触控事件但无回调注册: page=%d comp=%d type=%s",
                event.page_id,
                event.component_id,
                event.event_type,
            )
            return

        for cb in callbacks:
            try:
                cb(event)
            except Exception as exc:
                logger.error("触控回调执行异常: %s", exc)

    # ------------------------------------------------------------------
    # 基础绘图指令封装
    # ------------------------------------------------------------------

    def cls(self, color: int = 0x0000) -> bool:
        """清屏，以指定颜色填充整个屏幕。

        发送 ``cls <color>`` 指令。

        Args:
            color: RGB565 颜色值，默认 ``0x0000`` (黑色)。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"cls {color:#06x}"
        return self.send_cmd(cmd)

    def fill_rect(
        self, x: int, y: int, w: int, h: int, color: int
    ) -> bool:
        """填充矩形区域。

        发送 ``fill <x>,<y>,<w>,<h>,<color>`` 指令。

        Args:
            x: 矩形左上角 X 坐标。
            y: 矩形左上角 Y 坐标。
            w: 矩形宽度（像素）。
            h: 矩形高度（像素）。
            color: RGB565 填充颜色。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"fill {x},{y},{w},{h},{color:#06x}"
        return self.send_cmd(cmd)

    def draw_line(
        self, x1: int, y1: int, x2: int, y2: int, color: int
    ) -> bool:
        """绘制直线。

        发送 ``line <x1>,<y1>,<x2>,<y2>,<color>`` 指令。

        Args:
            x1: 起点 X 坐标。
            y1: 起点 Y 坐标。
            x2: 终点 X 坐标。
            y2: 终点 Y 坐标。
            color: RGB565 线条颜色。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"line {x1},{y1},{x2},{y2},{color:#06x}"
        return self.send_cmd(cmd)

    def draw_rect(
        self, x: int, y: int, w: int, h: int, color: int
    ) -> bool:
        """绘制矩形边框。

        发送 ``draw <x>,<y>,<w>,<h>,<color>`` 指令。

        Args:
            x: 矩形左上角 X 坐标。
            y: 矩形左上角 Y 坐标。
            w: 矩形宽度（像素）。
            h: 矩形高度（像素）。
            color: RGB565 边框颜色。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"draw {x},{y},{w},{h},{color:#06x}"
        return self.send_cmd(cmd)

    def draw_circle(self, x: int, y: int, r: int, color: int) -> bool:
        """绘制实心圆。

        发送 ``cirs <x>,<y>,<r>,<color>`` 指令（陶晶驰画实心圆指令）。

        Args:
            x: 圆心 X 坐标。
            y: 圆心 Y 坐标。
            r: 圆半径（像素）。
            color: RGB565 填充颜色。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"cirs {x},{y},{r},{color:#06x}"
        return self.send_cmd(cmd)

    def draw_text(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        font: int,
        text_color: int,
        back_color: int,
        align: int,
        text: str,
    ) -> bool:
        """在指定区域绘制文本。

        发送 ``xstr <x>,<y>,<w>,<h>,<font>,<text_color>,<back_color>,<align>,<text>`` 指令。

        Args:
            x: 文本区域左上角 X 坐标。
            y: 文本区域左上角 Y 坐标。
            w: 区域宽度（像素）。
            h: 区域高度（像素）。
            font: 字体编号（陶晶驰字体 ID）。
            text_color: RGB565 文本颜色。
            back_color: RGB565 背景颜色（透明背景可用特殊值）。
            align: 对齐方式（0=左对齐, 1=居中, 2=右对齐）。
            text: 要显示的文本内容。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = (
            f"xstr {x},{y},{w},{h},{font},"
            f"{text_color:#06x},{back_color:#06x},{align},"
            f"{text}"
        )
        return self.send_cmd(cmd)

    def refresh_area(self, x: int, y: int, w: int, h: int) -> bool:
        """刷新指定矩形区域。

        发送 ``ref <x>,<y>,<w>,<h>`` 指令，将绘图缓冲区的内容更新到屏幕上。

        Args:
            x: 区域左上角 X 坐标。
            y: 区域左上角 Y 坐标。
            w: 区域宽度（像素）。
            h: 区域高度（像素）。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"ref {x},{y},{w},{h}"
        return self.send_cmd(cmd)

    def goto_page(self, page_id: int) -> bool:
        """跳转到指定页面。

        发送 ``page <page_id>`` 指令。

        Args:
            page_id: 目标页面 ID。

        Returns:
            指令发送成功返回 ``True``。
        """
        cmd = f"page {page_id}"
        return self.send_cmd(cmd)

    # ------------------------------------------------------------------
    # 高级辅助
    # ------------------------------------------------------------------

    def wait_for_ready(self, timeout: float = 10.0) -> bool:
        """等待串口屏启动完成。

        在指定超时时间内持续读取串口数据，监听 ``0x88`` 启动完成事件。
        若收到启动完成信号则立即返回成功。

        Args:
            timeout: 最长等待时间（秒），默认 ``10.0``。

        Returns:
            在超时前收到启动信号返回 ``True``，否则返回 ``False``。
        """
        if not self.is_connected():
            logger.error("wait_for_ready 失败: 串口未连接")
            return False

        deadline = time.time() + timeout
        buffer = bytearray()

        logger.info("等待串口屏启动完成信号 (0x88)，超时 %.1f 秒...", timeout)

        while time.time() < deadline:
            try:
                with self._cmd_lock:
                    chunk = self._serial.read_all()
                if chunk:
                    buffer.extend(chunk)

                # 查找启动完成信号 0x88 0xFF 0xFF 0xFF
                target = b"\x88\xff\xff\xff"
                buf_bytes = bytes(buffer)
                idx = buf_bytes.find(target)
                if idx != -1:
                    logger.info("串口屏启动完成 (0x88 已收到)")
                    del buffer[: idx + 4]
                    return True

                # 清理旧缓冲区防止无限增长
                if len(buffer) > 256:
                    del buffer[:128]

                time.sleep(0.1)
            except Exception as exc:
                logger.error("等待启动时发生错误: %s", exc)
                time.sleep(0.2)

        logger.warning("等待串口屏启动超时 (%.1f 秒)", timeout)
        return False

    # ------------------------------------------------------------------
    # 属性访问
    # ------------------------------------------------------------------

    @property
    def width(self) -> int:
        """屏幕宽度（像素）。"""
        return self._width

    @property
    def height(self) -> int:
        """屏幕高度（像素）。"""
        return self._height

    def __repr__(self) -> str:
        return (
            f"TJCScreen(port={self._port}, baudrate={self._baudrate}, "
            f"connected={self.is_connected()}, size={self._width}x{self._height})"
        )
