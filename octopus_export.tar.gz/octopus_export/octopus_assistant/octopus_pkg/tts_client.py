"""TTS 客户端 — 文字转语音.

使用 edge-tts (在线，中文质量好) 作为主引擎，
espeak-ng (离线) 作为 fallback。

队列串行化设计：所有 speak 请求进入队列，单消费者线程依次播放，
彻底解决扬声器重叠和回授问题。

用法:
    from octopus_pkg.tts_client import TTSClient
    tts = TTSClient(enabled=True)
    tts.speak("你好，我是章鱼助手")
    tts.speak("第二句话会排队等待第一句播完")
    tts.stop()  # 清空队列并停止当前播放
"""

from __future__ import annotations

import asyncio
import logging
import os
import queue
import subprocess
import threading
import uuid
from typing import Optional

logger = logging.getLogger("octopus.tts")


class TTSClient:
    """TTS 客户端（队列串行化版）.

    特性:
    - edge-tts 主引擎 (Microsoft Edge 在线语音，中文自然)
    - espeak-ng fallback (离线，无网可用)
    - 单消费者线程依次播放，绝不重叠
    - 新语音自动打断旧语音（清空队列 + 终止当前）
    """

    def __init__(
        self,
        voice: str = "zh-CN-XiaoxiaoNeural",
        rate: str = "+0%",
        enabled: bool = True,
    ) -> None:
        self.voice = voice
        self.rate = rate
        self.enabled = enabled

        self._q: queue.Queue[str] = queue.Queue()
        self._worker_thread: Optional[threading.Thread] = None
        self._current_proc: Optional[subprocess.Popen] = None
        self._proc_lock = threading.Lock()
        self._running = False
        self._stop_event = threading.Event()

    def speak(self, text: str) -> None:
        """朗读文本（入队，单线程串行播放）."""
        if not self.enabled or not text:
            return
        text = text.strip()[:300]
        self._q.put(text)
        logger.debug("[tts] 入队: %s...", text[:30])

        # 确保消费者线程在运行
        if self._worker_thread is None or not self._worker_thread.is_alive():
            self._start_worker()

    def stop(self) -> None:
        """停止播放，清空队列."""
        # 清空队列
        while not self._q.empty():
            try:
                self._q.get_nowait()
            except queue.Empty:
                break

        # 终止当前播放
        with self._proc_lock:
            self._kill_current()

        self._stop_event.set()
        if self._worker_thread and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=2.0)
        self._running = False

    def is_speaking(self) -> bool:
        """当前是否正在播放语音（用于麦克风隔绝）."""
        with self._proc_lock:
            if self._current_proc is None:
                return False
            return self._current_proc.poll() is None

    # ------------------------------------------------------------------
    # 内部
    # ------------------------------------------------------------------

    def _start_worker(self) -> None:
        """启动单消费者播放线程."""
        self._running = True
        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            name="TTS-Worker",
            daemon=True,
        )
        self._worker_thread.start()

    def _worker_loop(self) -> None:
        """消费者循环：依次从队列取出文本并播放."""
        while self._running and not self._stop_event.is_set():
            try:
                text = self._q.get(timeout=0.5)
            except queue.Empty:
                continue

            if self._stop_event.is_set():
                break

            logger.debug("[tts] 播放: %s...", text[:30])
            self._do_speak(text)

        self._running = False

    def _do_speak(self, text: str) -> None:
        """执行单条朗读（在消费者线程中）."""
        # 优先 edge-tts
        try:
            self._speak_edge_tts(text)
            return
        except Exception as e:
            logger.debug("edge-tts 失败: %s", e)

        # fallback espeak-ng
        try:
            self._speak_espeak(text)
        except Exception as e:
            logger.error("TTS 全部失败: %s", e)

    def _speak_edge_tts(self, text: str) -> None:
        """使用 edge-tts 生成并播放."""
        import edge_tts

        tmp_path = f"/tmp/tts_{uuid.uuid4().hex[:8]}.mp3"

        async def _generate() -> None:
            communicate = edge_tts.Communicate(
                text,
                voice=self.voice,
                rate=self.rate,
            )
            await communicate.save(tmp_path)

        asyncio.run(_generate())

        proc = subprocess.Popen(
            [
                "ffplay",
                "-nodisp",
                "-autoexit",
                "-loglevel", "quiet",
                tmp_path,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        with self._proc_lock:
            self._current_proc = proc

        proc.wait()

        with self._proc_lock:
            self._current_proc = None

        # 清理临时文件
        try:
            os.remove(tmp_path)
        except OSError:
            pass

    def _speak_espeak(self, text: str) -> None:
        """使用 espeak-ng 直接播放（离线 fallback）."""
        proc = subprocess.Popen(
            ["espeak-ng", "-v", "zh", text],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        with self._proc_lock:
            self._current_proc = proc

        proc.wait()

        with self._proc_lock:
            self._current_proc = None

    def _kill_current(self) -> None:
        """终止当前播放进程."""
        if self._current_proc is None:
            return

        if self._current_proc.poll() is None:
            try:
                self._current_proc.terminate()
                self._current_proc.wait(timeout=1.0)
            except Exception:
                try:
                    self._current_proc.kill()
                    self._current_proc.wait(timeout=1.0)
                except Exception:
                    pass

        self._current_proc = None
