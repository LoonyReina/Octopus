"""章鱼触手爪子控制器 — STM32 RT1064 舵机控制封装.

基于 /home/openEuler/stm32_uart/uart_test.py 封装，提供线程安全的便捷接口：
- 收缩/张开所有爪子
-  happy 情绪时的波浪动作
-  单爪独立控制

用法:
    from octopus_pkg.claw_controller import ClawController
    claws = ClawController()
    claws.happy_wave()
    claws.retract_all()
    claws.close()
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

logger = logging.getLogger("octopus.claw")


class ClawController:
    """章鱼触手爪子控制器.

    控制 4 路舵机：0=C30, 1=D0, 2=D1, 3=C7
    串口: /dev/ttyAMA1 @ 115200
    """

    # 舵机名
    NAMES = {0: "S0:C30", 1: "S1:D0", 2: "S2:D1", 3: "S3:C7"}

    # 角度定义
    ANGLE_RETRACTED = 0      # 收缩（爪子闭合）
    ANGLE_EXTENDED = 180     # 张开（爪子展开）
    ANGLE_NEUTRAL = 90       # 中间位置

    def __init__(self, port: str = "/dev/ttyAMA1", baudrate: int = 115200) -> None:
        self.port = port
        self.baudrate = baudrate
        self._lock = threading.Lock()
        self._ser: Optional[object] = None
        self._available = False

        try:
            import serial
            self._ser = serial.Serial(
                port=port,
                baudrate=baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.1,
            )
            if self._ser.is_open:
                self._available = True
                logger.info("爪子控制器已连接: %s @ %d", port, baudrate)
        except Exception as e:
            logger.warning("爪子控制器连接失败: %s", e)

    def is_available(self) -> bool:
        return self._available

    def set_servo(self, servo_id: int, angle: int) -> bool:
        """设置单个舵机角度（线程安全）."""
        if not self._available or self._ser is None:
            return False
        if not (0 <= servo_id <= 3):
            logger.warning("舵机ID %d 超出范围(0-3)", servo_id)
            return False
        if not (0 <= angle <= 180):
            logger.warning("角度 %d 超出范围(0-180)", angle)
            return False

        with self._lock:
            try:
                cmd = f"CMD:SERVO,{servo_id},{angle}\n"
                self._ser.write(cmd.encode("utf-8"))

                # 等待 ACK，最多 0.1 秒（避免阻塞后续舵机）
                start = time.time()
                rx_buf = ""
                while time.time() - start < 0.1:
                    if self._ser.in_waiting > 0:
                        rx_buf += self._ser.read(self._ser.in_waiting).decode("utf-8", errors="ignore")
                        if "\n" in rx_buf:
                            idx = rx_buf.index("\n")
                            line = rx_buf[:idx].strip()
                            if line.startswith("ACK:OK"):
                                logger.debug("爪子 %s -> %d°", self.NAMES[servo_id], angle)
                                return True
                            elif line.startswith("ACK:ERR"):
                                logger.warning("爪子 %s 返回错误: %s", self.NAMES[servo_id], line)
                                return False
                    time.sleep(0.02)

                logger.debug("爪子 %s -> %d° (无ACK)", self.NAMES[servo_id], angle)
                return True  # 无ACK也视为成功，避免阻塞
            except Exception as e:
                logger.warning("设置爪子异常: %s", e)
                return False

    def set_all(self, angles: list[int]) -> None:
        """同时设置 4 路舵机."""
        if len(angles) != 4:
            logger.warning("angles 必须是长度为4的列表")
            return
        for i, a in enumerate(angles):
            self.set_servo(i, a)
            time.sleep(0.05)

    def retract_all(self) -> None:
        """收缩所有爪子（闭合）."""
        logger.info("[claw] 收缩所有爪子")
        self.set_all([self.ANGLE_RETRACTED] * 4)

    def extend_all(self) -> None:
        """张开所有爪子."""
        logger.info("[claw] 张开所有爪子")
        self.set_all([self.ANGLE_EXTENDED] * 4)

    def reset_all(self) -> None:
        """全部回中 90°."""
        logger.info("[claw] 爪子回中")
        self.set_all([self.ANGLE_NEUTRAL] * 4)

    def happy_wave(self) -> None:
        """开心时的波浪动作（依次张开收缩）."""
        if not self._available:
            return
        logger.info("[claw] 开心波浪")

        def _wave():
            # 依次张开
            for i in range(4):
                self.set_servo(i, self.ANGLE_EXTENDED)
                time.sleep(0.15)
            time.sleep(0.3)
            # 依次收缩
            for i in range(4):
                self.set_servo(i, self.ANGLE_RETRACTED)
                time.sleep(0.15)
            time.sleep(0.2)
            # 回中
            self.reset_all()

        threading.Thread(target=_wave, daemon=True).start()

    def close(self) -> None:
        """关闭串口，舵机回中."""
        if self._ser and self._ser.is_open:
            try:
                self.reset_all()
                time.sleep(0.2)
                self._ser.close()
                logger.info("[claw] 串口已关闭，舵机已回中")
            except Exception as e:
                logger.warning("关闭爪子控制器异常: %s", e)

    def __del__(self) -> None:
        self.close()
